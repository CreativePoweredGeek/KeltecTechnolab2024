<?php
/**
 * This source file is part of the open source project
 * ExpressionEngine (https://expressionengine.com)
 *
 * @link      https://expressionengine.com/
 * @copyright Copyright (c) 2003-2019, EllisLab Corp. (https://ellislab.com)
 * @license   https://expressionengine.com/license Licensed under Apache License, Version 2.0
 */

/**
 * Blacklist front end (nada)
 */
class Blacklist {

	var $return_data  = '';

	/**
	  * Constructor
	  */
	function __construct()
	{
		return $this->return_data;
	}

}
// END CLASS

// EOF
