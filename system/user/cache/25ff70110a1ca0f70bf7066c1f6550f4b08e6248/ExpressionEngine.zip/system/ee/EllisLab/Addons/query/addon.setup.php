<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'Query',
	'description' => '',
	'version'     => '2.0.0',
	'namespace'   => 'EllisLab\Addons\Query',
	'settings_exist' => FALSE,
);
