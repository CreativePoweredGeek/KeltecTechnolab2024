<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'Moblog',
	'description' => '',
	'version'     => '3.3.0',
	'namespace'   => 'EllisLab\Addons\Moblog',
	'settings_exist' => TRUE,
	'models' => array(
		'Moblog' => 'Model\Moblog'
	)
);

// EOF
