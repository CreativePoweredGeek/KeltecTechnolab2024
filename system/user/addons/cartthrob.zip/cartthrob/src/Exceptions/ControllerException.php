<?php

namespace CartThrob\Exceptions;

class ControllerException extends CartThrobException
{
}
