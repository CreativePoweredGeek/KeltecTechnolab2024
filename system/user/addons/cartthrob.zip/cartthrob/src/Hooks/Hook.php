<?php

namespace CartThrob\Hooks;

abstract class Hook
{
}
