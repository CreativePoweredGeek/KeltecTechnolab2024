<?php

namespace CartThrob\PaymentGateways;

use CartThrob\Plugins\Payment\PaymentPlugin;

abstract class AbstractPaymentGateway extends PaymentPlugin
{
}
