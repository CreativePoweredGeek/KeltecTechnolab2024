<fieldset class="credit_card_info" id="credit_card_info">
    <legend>Credit Card Info</legend>
    <div class="control-group" style="margin:auto;width:80%">
        <!-- placeholder for Elements -->
        <div id="card-element"></div>
    </div>
</fieldset>