<fieldset class="credit_card_info" id="credit_card_info">
    <legend>Choose PayPal Option</legend>
    <div class="control-group" style="margin:auto;width:80%">
        <div id="paypal-button-container"></div>
    </div>
</fieldset>