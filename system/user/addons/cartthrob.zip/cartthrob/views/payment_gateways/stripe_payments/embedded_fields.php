<fieldset class="credit_card_info" id="credit_card_info">
    <legend>Credit Card Info</legend>
    <div class="control-group" style="margin:auto;width:80%">
        <div id="payment-request-button">
            <!-- A Stripe Element will be inserted here. -->
        </div>
        <!-- placeholder for Elements -->
        <div id="payment-element">
            <!-- Elements will create form elements here -->
        </div>
        <div id="error-message">
            <!-- Display error message to your customers here -->
        </div>
    </div>
</fieldset>