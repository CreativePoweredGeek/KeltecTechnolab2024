<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * CartThrob Scripts
 */
class Cartthrob_scripts
{
}
