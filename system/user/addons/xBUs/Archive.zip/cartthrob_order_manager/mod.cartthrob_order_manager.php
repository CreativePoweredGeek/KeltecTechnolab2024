<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Cartthrob_order_manager
{
    public $return_data;

    public function __construct()
    {
        ee()->load->library(['number', 'form_builder', 'template_helper']);
    }
}
