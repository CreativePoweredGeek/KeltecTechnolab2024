<?php

use Illuminate\Support\Arr;

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/* @var Cartthrob_mcp $cartthrob_mcp */
/* @var array $plugins */
/* @var string $plugin_type */
/* @var string $extload_url */
?>

<?php foreach ($plugins as $plugin) : ?>
    <?php $className = $plugin['classname']; ?>

    <div style="display:none;" class="<?= $plugin_type; ?>_settings" id="<?= $className; ?>">

        <?php if ($plugin_type === 'payment_gateway' && !empty($plugin['extload'])) : ?>
            <div class="box check-extload" style="display: none; margin-bottom: 10px;">
                <h1>extload.php</h1>
                <div style="padding: 10px 10px 0;">
                    <div class="alert inline success" style="display: none; margin-bottom: 0;">
                        <p>extload.php is configured properly</p>
                    </div>
                    <div class="alert inline issue" style="display: none; margin-bottom: 0;">
                        <h4>This payment gateway requires the use of extload.php, which could not be loaded.</h4>
                        <p>Please refer to the documentation on extload.php: <a href="https://www.cartthrob.com/docs/payments/extload/index.html" target="_blank">https://www.cartthrob.com/docs/payments/extload/index.html</a></p>
                        <hr />
                        <p>Ajax response from <a href="<?php echo $extload_url; ?>" target="_blank"><?php echo $extload_url; ?></a>:</p>
                        <pre class="request-info" style="padding: 10px; background: rgba(0, 0, 0, 0.1); border: 1px solid #272000;"></pre>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!isset($plugin['settings'])) : ?>
            <table class="mainTable padTable">
                <thead class="">
                <tr>
                    <th colspan="2">
                        <strong><?= lang($plugin['short_title'] ?? $plugin['title']); ?></strong><br />
                    </th>
                </tr>
                </thead>
                <tbody>
                    <?php if (!empty($plugin['note'])) : ?>
                        <tr class="<?= alternator('odd', 'even'); ?>">
                            <td colspan="2">
                                <div class="subtext note"><?= lang('gateway_settings_note_title'); ?></div>
                                <?= lang($plugin['note']); ?>
                            </td>
                        </tr>
                    <?php endif; ?>

                    <?php if (!empty($plugin['overview'])) : ?>
                        <tr class="<?= alternator('odd', 'even'); ?>">
                            <td colspan="2">
                                <div class="ct_overview">
                                    <?= lang($plugin['overview']); ?>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php else: ?>
            <table class="mainTable padTable">
                <thead class="">
                    <tr>
                        <th colspan="2">
                            <strong><?= lang($plugin['title']); ?> <?= lang('settings'); ?></strong><br />
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($plugin['note'])) : ?>
                        <tr class="<?= alternator('odd', 'even'); ?>">
                            <td colspan="2">
                                <div class="subtext note"><?= lang('gateway_settings_note_title'); ?></div>
                                <?= lang($plugin['note']); ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <?php if (!empty($plugin['overview'])) : ?>
                        <tr class="<?= alternator('odd', 'even'); ?>">
                            <td colspan="2">
                                <div class="ct_overview">
                                    <?= lang($plugin['overview']); ?>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php if (is_array($plugin['settings'])) : ?>
                <?php foreach ($plugin['settings'] as $setting) : ?>
                    <?php $classNameShortName = $className . '_' . $setting['short_name']; ?>
                    <?php if ($setting['type'] == 'matrix') : ?>
                        <?php
                            //retrieve the current set value of the field
                            $current_values = $settings[$className . '_settings'][$setting['short_name']] ?? false;
                            //set the value to the default value if there is no set value and the default value is defined
                            $current_values = ($current_values === false && isset($setting['default'])) ? $setting['default'] : $current_values;
                        ?>
                        <div class="matrix">
                            <table class="mainTable padTable">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <?php foreach ($setting['settings'] as $count => $matrixSetting) : ?>
                                            <?php
                                                $style = '';
                                                $setting['settings'][$count]['style'] = $style;
                                            ?>
                                            <th>
                                                <strong><?= lang($matrixSetting['name']); ?></strong>
                                                <?= isset($matrixSetting['note']) ? '<br />' . lang($matrixSetting['note']) : ''; ?>
                                            </th>
                                        <?php endforeach; ?>
                                        <th style="width:20px;"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        if ($current_values === false || !count($current_values)) {
                                            $current_values = [[]];
                                            foreach ($setting['settings'] as $matrixSetting) {
                                                $current_values[0][$matrixSetting['short_name']] = $matrixSetting['default'] ?? '';
                                            }
                                        }
                                    ?>
                                    <?php foreach ($current_values as $count => $currentValue) : ?>
                                        <tr class="<?= $classNameShortName; ?>_setting"
                                            rel = "<?= $className . '_settings[' . $setting['short_name'] . ']'; ?>"
                                            id="<?= $classNameShortName; ?>_setting_<?= $count; ?>"
                                        >
                                            <td><img alt="" src='<?= URL_THIRD_THEMES; ?>cartthrob/images/ct_drag_handle.gif' width="10" height="17" /></td>
                                            <?php foreach ($setting['settings'] as $matrixSetting) : ?>
                                                <td style="<?= $matrixSetting['style']; ?>" rel="<?= $matrixSetting['short_name']; ?>">
                                                    <?=
                                                        $cartthrob_mcp->pluginControlHtml(
                                                            $matrixSetting['type'],
                                                            $className . '_settings[' . $setting['short_name'] . '][' . $count . '][' . $matrixSetting['short_name'] . ']',
                                                            Arr::get($currentValue, $matrixSetting['short_name'], ''),
                                                            Arr::get($matrixSetting, 'options', []),
                                                            Arr::get($matrixSetting, 'attributes', [])
                                                        );
                                                    ?>
                                                </td>
                                            <?php endforeach; ?>
                                            <td>
                                                <a href="#" class="remove_matrix_row">
                                                    <b class="ico settings trash"></b>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <fieldset class="plugin_add_new_setting">
                            <a href="#" class="ct_add_matrix_row btn action" id="add_new_<?= $classNameShortName; ?>">
                                <?= lang('add_another_row'); ?>
                            </a>
                        </fieldset>

                        <table style="display: none;" class="<?= $className; ?>">
                            <tr id="<?= $classNameShortName; ?>_blank" class="<?= $setting['short_name']; ?>">
                                <td><img alt="" src='<?= URL_THIRD_THEMES; ?>cartthrob/images/ct_drag_handle.gif' width="10" height="17" /></td>

                                <?php foreach ($setting['settings'] as $matrixSetting) : ?>
                                    <td class="<?= $matrixSetting['short_name']; ?>" style="<?= $matrixSetting['style']; ?>">
                                        <?=
                                            $cartthrob_mcp->pluginControlHtml(
                                                Arr::get($matrixSetting, 'type'),
                                                $name = '',
                                                Arr::get($matrixSetting, 'default', ''),
                                                Arr::get($matrixSetting, 'options'),
                                                Arr::get($matrixSetting, 'attributes')
                                            );
                                        ?>
                                    </td>
                                <?php endforeach; ?>
                                <td>
                                    <a href="#" class="remove_matrix_row"><b class="ico settings trash"></b></a>
                                </td>
                            </tr>
                        </table>
                    <?php elseif ($setting['type'] == 'header') : ?>
                        <table class="mainTable padTable">
                            <thead class="">
                                <tr>
                                    <th colspan="2">
                                        <strong><?= $setting['name']; ?></strong><br />
                                    </th>
                                </tr>
                            </thead>
                        </table>
                    <?php elseif ($setting['type'] == 'add_to_head') : ?>
                        <?= $cartthrob_mcp->pluginControlHtml('add_to_head', '', Arr::get($setting, 'default', '')); ?>
                    <?php elseif ($setting['type'] == 'add_to_foot') : ?>
                        <?= $cartthrob_mcp->pluginControlHtml('add_to_foot', '', Arr::get($setting, 'default', '')); ?>
                    <?php else : ?>
                        <?php
                            //retrieve the current set value of the field
                            $currentValue = $settings[$className . '_settings'][$setting['short_name']] ?? false;
                            //set the value to the default value if there is no set value and the default value is defined
                            $currentValue = ($currentValue === false && isset($setting['default'])) ? $setting['default'] : $currentValue;
                        ?>
                        <table class="mainTable padTable">
                        <tbody>
                            <tr class="even">
                                <td>
                                    <label><?= lang($setting['name']); ?></label><br><span class="subtext"><?= isset($setting['note']) ? lang($setting['note']) : ''; ?></span>
                                </td>
                                <td style='width:50%;'>
                                    <?=
                                        $cartthrob_mcp->pluginControlHtml(
                                            $setting['type'],
                                            $className . '_settings[' . $setting['short_name'] . ']',
                                            $currentValue,
                                            Arr::get($setting, 'options', []),
                                            Arr::get($setting, 'attributes', [])
                                        );
                                    ?>
                                </td>
                            </tr>
                        </tbody>
                        </table>
                    <?php endif; ?>
                <?php endforeach; ?>
            <?php endif; ?>
        <?php endif; ?>

        <?php if (!empty($plugin['required_fields'])) : ?>
            <table class="mainTable padTable">
                <thead class="">
                    <tr>
                        <th >
                            <strong><?= lang('gateways_required_fields'); ?></strong><br />
                            <?= lang('gateways_required_fields_description'); ?>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($plugin['required_fields'] as $value) : ?>
                        <tr class="<?= alternator('odd', 'even'); ?>">
                            <td><?= $value; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <?php if (!empty($plugin['html'])) : ?>
            <table class="mainTable padTable">
                <thead class="">
                    <tr>
                        <th><?= lang('gateways_sample_html'); ?><br /><br /></th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="<?= alternator('odd', 'even'); ?>">
                        <td>
                            <textarea rows="50" style="font-size:10px;" readonly><?= htmlentities($plugin['html']); ?></textarea>
                        </td>
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>

        <?php if ($plugin_type === 'payment_gateway' && count($plugins) > 1) : ?>
            <table class="mainTable padTable">
                <thead class="">
                    <tr>
                        <th colspan="2">
                            <strong><?= lang($plugin['title']); ?> <?= lang('settings'); ?></strong><br />
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="<?= alternator('odd', 'even'); ?>">
                        <td>
                            <div class="subtext"><?= lang('plugin_select'); ?></div>
                        </td>
                        <td style='width:50%;'>
                            <?= Cartthrob_core::get_class($className); ?>
                        </td>
                    </tr>
                    <tr class="<?= alternator('odd', 'even'); ?>">
                        <td>
                            <div class="subtext"><?= lang('gateways_form_input'); ?></div>
                        </td>
                        <td style='width:50%;'>
                            <?= ($encoded = ee('Encrypt')->encode(Cartthrob_core::get_class($className))); ?>
                        </td>
                    </tr>
                    <tr class="<?= alternator('odd', 'even'); ?>">
                        <td>
                            <div class="subtext"><?= lang('gateways_form_input_urlencoded'); ?></div>
                        </td>
                        <td style='width:50%;'>
                            <?= urlencode($encoded); ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>


        <?php if (!empty($plugin['additional_template_fields'])) : ?>
            <table class="mainTable padTable">
                <thead class="">
                    <tr>
                        <th colspan="2">
                            <strong><?= lang('plugins_fields'); ?></strong><br />
                            <p><?= lang('plugins_in_addition_to'); ?><a href='http://cartthrob.com/docs/tags_detail/checkout_form/'><?= lang('plugins_field_notes'); ?></p><br />
                        </th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($plugin['additional_template_fields'] as $template_field) : ?>
                    <tr class="<?= alternator('odd', 'even'); ?>">
                        <td>
                            <strong <?php if ($template_field['required']) : ?> class='red'<?php endif; ?>><?= $template_field['name']; ?></strong><br />
                            <?php if (isset($template_field['description'])) : ?>
                                <?= $template_field['description']; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            Field Name: <?= $template_field['short_name']; ?><br />
                            <?php if (isset($template_field['option_values'])) : ?>
                                Expected values: <?= $template_field['option_values']; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
<?php endforeach; ?>
