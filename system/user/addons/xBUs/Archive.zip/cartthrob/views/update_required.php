<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<link href="<?=URL_THIRD_THEMES?>cartthrob/css/cartthrob.css" rel="stylesheet" type="text/css" />

<!-- begin right column -->
	<div id="ct_system_error">
		<h4><?=lang('update_required')?></h4>
	</div>
	
	<p><?=lang('cartthrob_run_module_updates')?></p>

