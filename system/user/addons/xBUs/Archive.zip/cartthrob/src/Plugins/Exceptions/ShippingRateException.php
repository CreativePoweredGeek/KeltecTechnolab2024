<?php

namespace CartThrob\Plugins\Exceptions;

use Exception;

class ShippingRateException extends Exception
{
}
