<?php

namespace CartThrob\Plugins\Tax;

use CartThrob\Plugins\Plugin;

abstract class TaxPlugin extends Plugin
{
}
