<?php

namespace CartThrob\Plugins;

use Exception;
use ReflectionClass;

abstract class Plugin
{
    public $title;
    public $short_title;
    public $overview;
    public $note;
    public $settings = [];

    public function initialize()
    {
    }

    /**
     * @param $key
     * @param $default
     * @return mixed
     */
    public function settings($key, $default = null)
    {
        return $this->settings[$key] ?? $default;
    }

    /**
     * Register the plugin with CartThrob
     */
    public function register(): void
    {
        try {
            $path = (new ReflectionClass($this))->getFileName();
            $baseName = str_replace(['_ext', '_ft', '_mcp', '_upd'], '', get_class($this));
            $idiom = set(ee()->session->userdata('language'), ee()->input->cookie('language'), ee()->config->item('deft_lang'), 'english');

            ee()->lang->load(
                $langfile = str_replace('\\', DIRECTORY_SEPARATOR, strtolower($baseName)),
                $idiom,
                $return = false,
                $add_suffix = true,
                $alt_path = dirname($path) . '/',
                $show_errors = false
            );
        } catch (Exception $e) {
            // NOOP
        }

        ee('cartthrob:PluginService')->register($this);
    }
}
