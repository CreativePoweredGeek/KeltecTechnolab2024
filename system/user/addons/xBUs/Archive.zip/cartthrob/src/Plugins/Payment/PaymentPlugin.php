<?php

namespace CartThrob\Plugins\Payment;

use CartThrob\Plugins\Plugin;

abstract class PaymentPlugin extends Plugin
{
}
