<?php

namespace CartThrob\Tags;

class CartDiscountTag extends Tag
{
    /**
     * Returns total discount amount for cart
     */
    public function process()
    {
        $value = ee()->cartthrob->cart->discount();

        switch (tag_param(2)) {
            case 'numeric':
                return $value;

            case 'minus_tax':
                /*
                 * We are ADDING the tax amount, because the discount will INCREASE due to the offset of the reduced tax
                 * applied to everything else based on this discount. Technically the discount is a negative amount... flip
                 * your brain... we're representing the total negative amount applied to the cart.
                 */
                $value = ee()->cartthrob->cart->discount() + ee()->cartthrob->cart->discount_tax();

                if (tag_param_equals(3, 'numeric')) {
                    return $value;
                }
                break;
        }

        return sprintf('%s%s',
            $this->param('prefix', '$'),
            number_format(
                $value,
                $decimals = (int)$this->param('decimals', 2),
                $decimalPoint = $this->param('dec_point', '.'),
                $thousandSeparator = $this->param('thousands_sep', ',')
            )
        );
    }
}
