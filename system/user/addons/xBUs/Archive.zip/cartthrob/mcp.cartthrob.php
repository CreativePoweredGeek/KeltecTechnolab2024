<?php

use Illuminate\Support\Collection;

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Cartthrob_mcp
{
    public static $nav = [
        'global_settings' => [
            'general_settings' => 'nav_general_settings',
            'number_format_defaults' => 'nav_number_format_defaults',
            'default_location' => 'nav_default_location',
            'locales' => 'nav_locales',
            'set_license_number' => 'nav_set_license_number',
        ],
        'product_settings' => [
            'product_channels' => 'nav_product_channels',
            'product_options' => 'nav_product_options',
        ],
        'order_settings' => [
            'order_channel_configuration' => 'nav_order_channel_configuration',
            'purchased_items' => 'nav_purchased_items',
        ],
        'shipping' => [
            'shipping' => 'nav_shipping',
        ],
        'taxes' => [
            'tax' => 'nav_tax',
        ],
        'coupons_discounts' => [
            'coupon_options' => 'nav_coupon_options',
            'discount_options' => 'nav_discount_options',
        ],
        'notifications' => [
            'notifications' => 'notifications',
        ],
        'members' => [
            'member_configuration' => 'nav_member_configuration',
        ],
        'payment_gateways' => [
            'payment_gateways' => 'nav_payment_gateways',
            'payment_security' => 'nav_payment_security',
        ],
        'reports' => [
            'reports' => 'reports',
        ],
        'installation' => [
            'install_channels' => 'nav_install_channels',
            'template_variables' => 'nav_template_variables',
        ],
        'import_export' => [
            'import_settings' => 'nav_import_settings',
            'export_settings' => 'nav_export_settings',
        ],
        'beta' => [
            'beta' => 'nav_beta',
        ],
        'add_tax' => [
            'add_tax' => '',
        ],
        'edit_tax' => [
            'edit_tax' => '',
        ],
        'delete_tax' => [
            'delete_tax' => '',
        ],
        'update_skus_action' => [
            'update_skus_action' => '',
        ],
    ];
    public static $subnav = [];
    public static $no_nav = [
        'edit_tax',
        'add_tax',
        'delete_tax',
        'update_skus_action',
    ];
    public $requiredSettings = [];
    public $extension_enabled = true;
    public $module_enabled = true;
    public $version;
    public $noForm = [
        'import_export',
        'reports',
        'add_tax',
        'taxes',
        'edit_tax',
        'delete_tax',
        'subscriptions_list',
        'subscriptions_vaults',
        'subscriptions_permissions',
        'update_skus_action',
    ];
    private $module_name;
    private $initialized = false;
    private $remove_keys = [
        'name',
        'submit',
        'x',
        'y',
        'XID',
        'CSRF_TOKEN',
    ];

    /* @var Package_installer */
    private $packageInstaller;

    public function __construct()
    {
        $this->module_name = strtolower(str_replace(['_ext', '_mcp', '_upd'], '', __CLASS__));

        ee()->load->helper(['debug', 'array']);
    }

    public function update()
    {
        require_once PATH_THIRD . 'cartthrob/upd.cartthrob.php';

        $upd = new Cartthrob_upd();
        $upd->sync();

        $this->index();
    }

    public function index()
    {
        ee()->functions->redirect(ee('CP/URL')->make('addons/settings/cartthrob/global_settings'));
    }

    /**
     * @return string
     */
    public function global_settings()
    {
        return $this->loadView(__FUNCTION__);
    }

    /**
     * @param $currentNav
     * @param array $more
     * @param array $structure
     * @return string
     */
    private function loadView($currentNav, $more = [], $structure = []): string
    {
        ee()->load->library('package_installer', ['xml' => PATH_THIRD . 'cartthrob/installer/installer.xml']);
        ee()->load->library('cartthrob_payments');
        ee()->load->library('addons');

        if (!ee()->config->item('encryption_key')) {
            ee()->cp->cp_page_title = ee()->lang->line('cartthrob_module_name') . ' - ' . ee()->lang->line('encryption_key');

            return ee()->load->view('encryption_key', [], true);
        }

        $modules = ee()->addons->get_installed();

        if (!isset($modules['cartthrob']['module_version']) || version_compare($this->version(), $modules['cartthrob']['module_version'], '>')) {
            ee()->cp->cp_page_title = ee()->lang->line('cartthrob_module_name') . ' - ' . ee()->lang->line('update_required');

            return ee()->load->view('update_required', [], true);
        }

        if ($this->isModuleEnabled('subscriptions')) {
            ee()->load->add_package_path(PATH_THIRD . 'cartthrob_subscriptions/');
        }

        $this->initialize();

        ee()->cp->cp_page_title = ee()->lang->line('cartthrob_module_name') . ' - ' . ee()->lang->line('nav_' . $currentNav);

        // if it's not set to TRUE, and there's an uninintialized setting (since the default settings haven't been loaded) we're screwed
        $settings = $this->saveSettings(true);

        if ($this->isModuleEnabled('subscriptions')) {
            if (!isset($settings['purchased_items_sub_id_field'])) {
                $settings['purchased_items_sub_id_field'] = null;
            }
        } elseif (isset($settings['purchased_items_sub_id_field'])) {
            unset($settings['purchased_items_sub_id_field']);
        }

        $siteId = null;
        if (ee()->config->item('cartthrob:msm_show_all')) {
            $siteId = 'all';
        }

        $channels = ee()->channel_model->get_channels($siteId)->result_array();
        $fields = [];
        $statuses = [];
        $viewPaths = [];
        $statusTitles = [];
        $channelTitles = [];
        $settingsViews = [];

        foreach ($channels as $channel) {
            $channelTitles[$channel['channel_id']] = $channel['channel_title'];

            // $fields[$channel['channel_id']] = ee()->field_model->get_fields($channel['field_group'])->result_array();
            // only want to capture a subset of data, because we're using this for JSON and we were getting too much data previously
            $channelFields = ee()->field_model->get_fields()->result_array();

            foreach ($channelFields as $key => &$data) {
                // This is 5.2 only... sigh this will eventually replace the 3 lines below.
                $fields[$channel['channel_id']][$key] = array_intersect_key($data, array_fill_keys(['field_id', 'site_id', 'group_id', 'field_name', 'field_type', 'field_label'], true));
            }

            $statuses[$channel['channel_id']] = ee()->cartthrob_settings_model->get_status_channels($channel['channel_id']);
        }

        foreach ($statuses as $status) {
            foreach ($status as $item) {
                $statusTitles[$item['status']] = $item['status'];
            }
        }

        if (!empty($settings['product_channels'])) {
            foreach ($settings['product_channels'] as $i => $channel_id) {
                if (!isset($channelTitles[$channel_id])) {
                    unset($settings['product_channels'][$i]);
                }
            }
        }

        if (!empty($settings['product_channel_fields'])) {
            foreach ($settings['product_channel_fields'] as $channel_id => $values) {
                if (!isset($channelTitles[$channel_id])) {
                    unset($settings['product_channel_fields'][$channel_id]);
                }
            }
        }

        $nav = self::nav();
        $noNav = self::$no_nav;

        // -------------------------------------------
        // 'cartthrob_add_settings_nav' hook.
        //
        if (ee()->extensions->active_hook('cartthrob_add_settings_nav') === true) {
            if ($addl_nav = ee()->extensions->call('cartthrob_add_settings_nav', $nav)) {
                $nav = array_merge($nav, $addl_nav);
            }
        }

        // -------------------------------------------
        // 'cartthrob_add_settings_views' hook.
        //
        if (ee()->extensions->active_hook('cartthrob_add_settings_views') === true) {
            $settingsViews = ee()->extensions->call('cartthrob_add_settings_views', $settingsViews);
        }

        if (is_array($settingsViews) && count($settingsViews)) {
            foreach ($settingsViews as $key => $value) {
                if (is_array($value)) {
                    if (isset($value['path'])) {
                        $viewPaths[$key] = $value['path'];
                    }

                    if (isset($value['title'])) {
                        $nav['more_settings'][$key] = $value['title'];
                    }
                } else {
                    $nav['more_settings'][$key] = $value;
                }
            }
        }

        $sections = [];

        foreach ($nav as $topNav => $_nav) {
            if ($topNav != $currentNav) {
                continue;
            }

            foreach ($_nav as $url_title => $section) {
                if (!preg_match('/^http/', $url_title)) {
                    $sections[] = $url_title;
                }
            }
        }

        $memberFields = ['' => '----'];

        if (ee()->cartthrob->store->config('use_profile_edit') && isset(ee()->extensions->extensions['channel_form_submit_entry_start'][10]['Profile_ext'])) {
            ee()->load->add_package_path(PATH_THIRD . 'profile/');
            ee()->load->model('profile_model');
            ee()->load->remove_package_path(PATH_THIRD . 'profile/');

            if ($profileEditChannelId = ee()->profile_model->settings('channel_id')) {
                // profile might be on a different MSM site, therefore it might not already be in the $fields array
                // let's double check
                if (isset($fields[$profileEditChannelId])) {
                    $profileFields = $fields[$profileEditChannelId];
                } else {
                    $siteId = ee()->profile_model->site_id();

                    if ($siteId != ee()->config->item('site_id')) {
                        ee()->cartthrob_field_model->load_fields($siteId);
                    }

                    $profileFields = ee()->cartthrob_field_model->get_fields_by_channel($profileEditChannelId);
                }

                foreach ($profileFields as $field) {
                    $memberFields[$field['field_id']] = $field['field_label'];
                }
            }
        } else {
            $m_fields = ee('Model')
                ->get('MemberField')
                ->fields('m_field_name', 'm_field_id', 'm_field_label')
                ->all();

            foreach ($m_fields as $row) {
                $memberFields[$row->m_field_id] = $row->m_field_label;
            }
        }

        $memberGroups = [];
        $query = ee('Model')->get('MemberGroup')->filter('group_id', '>=', '5')->all();

        foreach ($query as $row) {
            $memberGroups[$row->group_id] = $row->group_title;
        }

        unset($query);

        foreach ($viewPaths as $path) {
            ee()->load->add_package_path($path);
        }

        ee()->load->library('paths');

        $data = [
            'structure' => $structure,
            'nav' => $nav,
            'subnav' => $this->hasSubnav($currentNav),
            'current_nav' => $currentNav,
            'sections' => $sections,
            'channels' => $channels,
            'channel_titles' => $channelTitles,
            'fields' => $fields,
            'statuses' => $statuses,
            'status_titles' => $statusTitles,
            'templates' => $this->templates(),
            'payment_gateways' => $this->paymentGateways(),
            'shipping_plugins' => $this->shippingPlugins(),
            'tax_plugins' => $this->taxPlugins(),
            'install_channels' => [],
            'install_template_groups' => [],
            'install_member_groups' => [],
            'view_paths' => $viewPaths,
            'cartthrob_mcp' => $this,
            'input' => ee()->input,
            'load' => ee()->load,
            'session' => ee()->session,
            'form_open' => form_open(ee('CP/URL')->make('addons/settings/cartthrob/quick_save', ['return' => ee()->uri->segment(5)])),
            'extension_enabled' => $this->extension_enabled,
            'module_enabled' => $this->module_enabled,
            'settings' => $settings,
            'orders_status' => $settings['orders_status'],
            'states_and_countries' => array_merge(
                ['global' => 'Global', '' => '---'],
                ee()->locales->states(),
                ['0' => '---'],
                ee()->locales->all_countries()
            ),
            'states' => ee()->locales->states(),
            'countries' => ee()->locales->all_countries(),
            'no_form' => in_array($currentNav, $this->noForm),
            'no_nav' => $noNav,
            'member_fields' => $memberFields,
            'member_groups' => $memberGroups,
            'customer_data_fields' => [
                'first_name',
                'last_name',
                'address',
                'address2',
                'city',
                'state',
                'zip',
                'country',
                'country_code',
                'company',
                'phone',
                'email_address',
                'use_billing_info',
                'shipping_first_name',
                'shipping_last_name',
                'shipping_address',
                'shipping_address2',
                'shipping_city',
                'shipping_state',
                'shipping_zip',
                'shipping_country',
                'shipping_country_code',
                'shipping_company',
                'language',
                'shipping_option',
                'region',
            ],
        ];

        foreach (ee()->package_installer->packages() as $index => $template) {
            /** @var SimpleXMLElement $template */
            switch ($template->getName()) {
                case 'channel':
                    $data['install_channels'][$index] = $template->attributes()->channel_title;
                    break;
                case 'template_group':
                    $data['install_template_groups'][$index] = $template->attributes()->group_name;
                    break;
                case 'member_group':
                    $data['install_member_groups'][$index] = $template->attributes()->group_name;
                    break;
            }
        }

        if (!empty($structure)) {
            $data['html'] = ee()->load->view('settings_template', $data, true);
        }

        $data['data'] = array_merge($data, $more);

        unset($self);

        ee()->cp->add_js_script('ui', 'accordion');
        ee()->cp->add_to_head('<link href="' . URL_THIRD_THEMES . 'cartthrob/css/cartthrob.css" rel="stylesheet" type="text/css" />');
        ee()->cp->add_to_foot(ee()->load->view('settings_form_head', $data, true));

        $output = ee()->load->view('settings_form', $data, true);

        foreach ($viewPaths as $path) {
            ee()->load->remove_package_path($path);
        }

        return $output;
    }

    /**
     * @return string
     */
    public function version(): string
    {
        if (is_null($this->version)) {
            $this->version = CARTTHROB_VERSION;
        }

        return $this->version;
    }

    private function initialize()
    {
        if ($this->initialized) {
            return;
        }

        $this->initialized = true;

        loadCartThrobPath();

        ee()->load->model(['cartthrob_settings_model', 'field_model', 'channel_model', 'product_model', 'generic_model', 'template_model']);
        ee()->load->library(['locales', 'languages', 'cartthrob_payments', 'get_settings', 'table', 'locales']);
        ee()->load->library('package_installer', ['xml' => PATH_THIRD . 'cartthrob/installer/installer.xml']);
        ee()->load->helper(['security', 'countries', 'data_formatting', 'form', 'file', 'string', 'inflector']);

        ee()->lang->loadfile('cartthrob', 'cartthrob');
        ee()->lang->loadfile('cartthrob_errors', 'cartthrob');

        $this->packageInstaller = new Package_installer(['xml' => PATH_THIRD . 'cartthrob/installer/installer.xml']);
        $this->module_enabled = (bool)ee()->db->where('module_name', 'Cartthrob')->count_all_results('modules');
        $this->extension_enabled = (bool)ee()->db->where([
            'class' => 'Cartthrob_ext',
            'enabled' => 'y',
        ])->count_all_results('extensions');
    }

    /**
     * @param bool $getAllSettings
     * @return array
     */
    public function saveSettings($getAllSettings = false): array
    {
        $settings = [];

        $savedSettings = ee()->db
            ->where('site_id', ee()->config->item('site_id'))->get('cartthrob_settings')
            ->result();

        foreach ($savedSettings as $row) {
            if ($row->serialized) {
                $settings[$row->key] = @unserialize($row->value);
            } else {
                $settings[$row->key] = $row->value;
            }
        }

        if ($getAllSettings) {
            $settings = array_merge($this->settings(), $settings);
        }

        return $settings;
    }

    /**
     * Loads cart, and gets default settings, then gets saved settings
     *
     * @param null
     * @return array
     */
    public function settings(): array
    {
        $this->initialize();

        return ee()->cartthrob_settings_model->get_settings();
    }

    /**
     * @return array
     */
    public static function nav(): array
    {
        static $built = false;

        if ($built) {
            return self::$nav;
        }

        $built = true;

        if (self::isModuleEnabled('subscriptions')) {
            self::$nav['subscriptions_settings'] = ['subscriptions_settings' => ''];
        }

        $modules = [
            'cartthrob_order_manager' => 'om_sales_dashboard',
            'ct_admin' => 'order_admin',
            'cartthrob_item_options' => 'global_item_options',
        ];

        foreach ($modules as $key => $module) {
            if (self::isModuleEnabled($key, null)) {
                self::$nav['modules'][$key] = [$key => $modules[$key]];
            }
        }

        return self::$nav;
    }

    /**
     * module_enabled
     *
     * use this to check if one or more modules are installed. If any one of the modules are not installed, false will be returned.
     *
     * @param string|array $modules list of modules to check
     * @param string $prefix . If not set, Cartthrob_ will be used.
     * @return bool
     */
    public static function isModuleEnabled($modules, $prefix = 'Cartthrob_'): bool
    {
        if (!is_array($modules)) {
            $modules = [$modules];
        }

        foreach ($modules as $module) {
            /** @var CI_DB_mysqli_result $query */
            $query = ee()->db
                ->select('module_name')
                ->where_in('module_name', $prefix . $module)
                ->get('modules');

            if (!$query->result()) {
                return false;
            }

            $query->free_result();
        }

        return true;
    }

    /**
     * @param $which
     * @return bool|mixed
     */
    public function hasSubnav($which)
    {
        foreach (self::$subnav as $subnav) {
            if (in_array($which, $subnav)) {
                return $subnav;
            }
        }

        return false;
    }

    /**
     * Loads payment gateway files
     *
     * @param null
     * @return array $gateways
     */
    public function paymentGateways(): array
    {
        $this->initialize();

        ee()->load->helper('file');
        ee()->load->library('api/api_cartthrob_payment_gateways');
        ee()->load->library('data_filter');
        ee()->load->model('template_model');

        $templates = ['' => ee()->lang->line('gateways_default_template')];
        /** @var CI_DB_mysqli_result $query */
        $query = ee()->template_model->get_templates();

        foreach ($query->result_array() as $row) {
            $templates[$row['group_name'] . '/' . $row['template_name']] = $row['group_name'] . '/' . $row['template_name'];
        }

        $gateways = ee()->api_cartthrob_payment_gateways->gateways();

        foreach ($gateways as &$pluginData) {
            ee()->lang->loadfile(strtolower($pluginData['classname']), 'cartthrob', false);

            foreach (['title', 'overview'] as $key) {
                if (isset($pluginData[$key])) {
                    $pluginData[$key] = ee()->lang->line($pluginData[$key]);
                }
            }

            $pluginData['html'] = ee()->api_cartthrob_payment_gateways
                ->set_gateway($pluginData['classname'])
                ->gateway_fields(true);

            if (isset($pluginData['settings']) && is_array($pluginData['settings'])) {
                foreach ($pluginData['settings'] as $key => $setting) {
                    $pluginData['settings'][$key]['name'] = ee()->lang->line($setting['name']);
                }

                $pluginData['settings'][] = [
                    'name' => ee()->lang->line('template_settings_name'),
                    'note' => ee()->lang->line('template_settings_note'),
                    'type' => 'select',
                    'short_name' => 'gateway_fields_template',
                    'options' => $templates,
                ];
            }
        }

        ee()->data_filter->sort($gateways, 'title');

        return $gateways;
    }

    /**
     * @return array
     */
    public function shippingPlugins(): array
    {
        return (new Collection($this->plugins('shipping')))
            ->map(function ($plugin) {
                $plugin['fulltext_title'] = lang($plugin['title']);

                return $plugin;
            })
            ->sortBy('fulltext_title')
            ->toArray();
    }

    /**
     * Loads shipping plugin files
     *
     * @param $type
     * @return array $plugins
     */
    private function plugins($type)
    {
        $this->initialize();

        $plugins = $this->loadLegacyPlugins($type);

        $this->loadPluginsByType($plugins, $type);

        return $plugins->toArray();
    }

    /**
     * @return array
     */
    public function taxPlugins()
    {
        return $this->plugins('tax');
    }

    public function templates()
    {
        static $templates;

        if (is_null($templates)) {
            $templates = [];

            ee()->load->model('template_model');

            $query = ee()->template_model->get_templates();

            foreach ($query->result() as $row) {
                $templates[$row->group_name . '/' . $row->template_name] = $row->group_name . '/' . $row->template_name;
            }
        }

        return $templates;
    }

    public function order_admin()
    {
        ee()->functions->redirect(ee('CP/URL')->make('addons/settings/ct_admin'));
    }

    public function global_item_options()
    {
        ee()->functions->redirect(ee('CP/URL')->make('addons/settings/cartthrob_item_options'));
    }

    /**
     * @return string
     */
    public function product_settings()
    {
        return $this->loadView(__FUNCTION__);
    }

    /**
     * @return string
     */
    public function order_settings()
    {
        return $this->loadView(__FUNCTION__);
    }

    /**
     * @return string
     */
    public function shipping()
    {
        return $this->loadView(__FUNCTION__);
    }

    /**
     * @return string
     */
    public function coupons_discounts()
    {
        return $this->loadView(__FUNCTION__);
    }

    /**
     * @return string
     */
    public function email_notifications()
    {
        return $this->loadView(__FUNCTION__);
    }

    /**
     * @return string
     */
    public function subscriptions_settings()
    {
        ee()->load->library('cartthrob_payments');
        ee()->load->library('api/api_cartthrob_payment_gateways');
        ee()->load->library('paths');

        if (!$this->isModuleEnabled('subscriptions')) {
            show_error('subscriptions_not_enabled'); // @TODO LANG
        }

        $vars['crontabulous_url'] = htmlentities(ee()->paths->build_action_url('Cartthrob_mcp', 'crontabulous_get_pending_subscriptions'), ENT_QUOTES, 'UTF-8', false);
        $vars['gateways'] = ee()->api_cartthrob_payment_gateways->subscription_gateways();

        ee()->cp->add_js_script(['ui' => ['core', 'widget', 'progressbar']]);

        return $this->loadView(__FUNCTION__, $vars, []);
    }

    /**
     * "Edit"-style list of subscriptions
     *
     * @return string
     */
    public function subscriptions_list()
    {
        return $this->loadView(__FUNCTION__);
    }

    // --------------------------------
    //  Plugin Settings
    // --------------------------------

    /**
     * "Edit"-style list of vaults
     *
     * @return string
     */
    public function subscriptions_vaults()
    {
        return $this->loadView(__FUNCTION__);
    }

    /**
     * "Edit"-style list of permissions
     *
     * @return string
     */
    public function subscriptions_permissions()
    {
        return $this->loadView(__FUNCTION__);
    }

    /**
     * @return string
     */
    public function notifications()
    {
        ee()->load->model(['field_model', 'channel_model', 'product_model']);

        $externalAppEvents = [];

        foreach (ee()->db->get('cartthrob_notification_events')->result() as $row) {
            $externalAppEvents[$row->application . '_' . $row->notification_event] = lang($row->application) . ': ' . lang($row->notification_event);
        }

        if (!empty($externalAppEvents)) {
            $emailEvents = [
                'payment_triggers' => [
                    'completed' => 'ct_completed',
                    'declined' => 'ct_declined',
                    'failed' => 'ct_failed',
                    'offsite' => 'ct_offsite',
                    'processing' => 'ct_processing',
                    'refunded' => 'ct_refunded',
                    'expired' => 'ct_expired',
                    'canceled' => 'ct_canceled',
                    'pending' => 'ct_pending',
                ],
                // why is status change set to blank?
                'other_events' => [
                    'low_stock' => 'ct_low_stock',
                    '' => 'status_change',
                ],
                'application_events' => $externalAppEvents,
            ];
        } else {
            $emailEvents = [
                'payment_triggers' => [
                    'completed' => 'ct_completed',
                    'declined' => 'ct_declined',
                    'failed' => 'ct_failed',
                    'offsite' => 'ct_offsite',
                    'processing' => 'ct_processing',
                    'refunded' => 'ct_refunded',
                    'expired' => 'ct_expired',
                    'canceled' => 'ct_canceled',
                    'pending' => 'ct_pending',
                ],
                // why is status change set to blank?
                'other_events' => [
                    'low_stock' => 'ct_low_stock',
                    '' => 'status_change',
                ],
            ];
        }

        $structure = [
            'class' => 'notifications',
            'stacked' => true,
            'description' => '',
            'caption' => '',
            'title' => 'notifications',
            'settings' => [
                [
                    'name' => 'log_email',
                    'note' => 'log_email_note',
                    'short_name' => 'log_email',
                    'default' => 'no',
                    'type' => 'select',
                    'options' => [
                        'no' => 'no',
                        'log_only' => 'log_only',
                        'log_and_send' => 'log_and_send',
                    ],
                ],
                [
                    'name' => 'notifications',
                    'short_name' => 'notifications',
                    'type' => 'matrix',
                    'settings' => [
                        [
                            'name' => 'email_subject',
                            'short_name' => 'email_subject',
                            'type' => 'text',
                        ],
                        [
                            'name' => 'email_from_name',
                            'short_name' => 'email_from_name',
                            'type' => 'text',
                        ],
                        [
                            'name' => 'email_from',
                            'short_name' => 'email_from',
                            'type' => 'text',
                        ],
                        [
                            'name' => 'email_reply_to_name',
                            'note' => 'email_reply_to_note',
                            'short_name' => 'email_reply_to_name',
                            'type' => 'text',
                        ],
                        [
                            'name' => 'email_reply_to',
                            'short_name' => 'email_reply_to',
                            'type' => 'text',
                        ],
                        [
                            'name' => 'email_to',
                            'short_name' => 'email_to',
                            'type' => 'text',
                            'default' => '{customer_email}',
                        ],
                        [
                            'name' => 'email_template',
                            'short_name' => 'email_template',
                            'type' => 'select',
                            'attributes' => [
                                'class' => 'templates',
                            ],
                        ],
                        [
                            'name' => 'cartthrob_initiated_event',
                            'short_name' => 'email_event',
                            'type' => 'select',
                            'default' => '',
                            'options' => $emailEvents,
                        ],
                        [
                            'name' => 'starting_status',
                            'short_name' => 'status_start',
                            'type' => 'select',
                            'default' => '---',
                            'attributes' => [
                                'class' => 'statuses_blank',
                            ],
                        ],
                        [
                            'name' => 'ending_status',
                            'short_name' => 'status_end',
                            'type' => 'select',
                            'default' => '---',
                            'attributes' => [
                                'class' => 'statuses_blank',
                            ],
                        ],
                        [
                            'name' => 'email_type',
                            'short_name' => 'email_type',
                            'type' => 'select',
                            'default' => 'html',
                            'options' => [
                                'html' => 'send_html_email',
                                'text' => 'send_text_email',
                            ],
                        ],
                    ],
                ],
            ],
        ];

        return $this->loadView(__FUNCTION__, [], $structure);
    }

    /**
     * @return string
     */
    public function payment_gateways()
    {
        ee()->load->library('javascript');

        $extloadUrl = ee()->config->slash_item('theme_folder_url') . 'user/cartthrob/lib/extload.php?cp_test=1';

        ee()->javascript->output('
            $.ajax({
                url: ' . json_encode($extloadUrl) . ',
                dataType: "text",
                success: function(data) {
                    $(".check-extload").show();
                    if (data !== "Success") {
                        $(".check-extload .alert.issue").show();
                        $(".check-extload .request-info").text(data);
                    } else {
                        $(".check-extload .alert.success").show();
                    }
                },
                error: function(xhr) {
                    $(".check-extload").show();
                    $(".check-extload .alert.issue").show();
                    $(".check-extload .request-info").text(xhr.status + " " + xhr.statusText);
                },
            });

            // prevent these events from bubbling up, causing all checkboxes to get checked
            $("table.mainTable").find(".checkboxes").on("click", function(e) {
                e.stopPropagation();
            }).find("input[type=checkbox]").on("change", function(e) {
                e.stopPropagation();
            });
        ');

        return $this->loadView(__FUNCTION__, ['extload_url' => $extloadUrl]);
    }

    // --------------------------------
    //  Save Settings
    // --------------------------------

    /**
     * @return string
     */
    public function members()
    {
        $profileEditActive = isset(ee()->extensions->extensions['channel_form_submit_entry_start'][10]['Profile_ext']) ? true : false;

        return $this->loadView(
            __FUNCTION__,
            ['profile_edit_active' => $profileEditActive]
        );
    }

    /**
     * @return string
     */
    public function import_export()
    {
        return $this->loadView(
            __FUNCTION__,
            ['form_open' => form_open(ee('CP/URL')->make('addons/settings/cartthrob/import_settings'), ['enctype' => 'multipart/form-data'])]
        );
    }

    /**
     * @return string
     */
    public function beta()
    {
        return $this->loadView(
            __FUNCTION__,
            ['form_edit' => form_open(ee('CP/URL')->make('addons/settings/cartthrob/form_update_beta'))]
        );
    }

    /**
     * @return string
     */
    public function installation()
    {
        return $this->loadView(
            __FUNCTION__,
            [
                'form_open' => form_open(ee('CP/URL')->make('addons/settings/cartthrob/install_templates')),
                'template_errors' => (ee()->session->flashdata('template_errors')) ? ee()->session->flashdata('template_errors') : [],
                'templates_installed' => (ee()->session->flashdata('templates_installed')) ? ee()->session->flashdata('templates_installed') : [],
                'theme_errors' => (ee()->session->flashdata('theme_errors')) ? ee()->session->flashdata('theme_errors') : [],
                'themes_installed' => (ee()->session->flashdata('themes_installed')) ? ee()->session->flashdata('themes_installed') : [],
                'themes' => $this->themes(),
            ]
        );
    }

    /**
     * @return array
     */
    private function themes()
    {
        if (ee()->config->item('cartthrob_third_party_path')) {
            $theme_base_path = ee()->config->slash_item('cartthrob_third_party_path') . 'installer/';
        } else {
            $theme_base_path = PATH_THIRD . 'cartthrob/third_party/installer/';
        }

        ee()->load->helper('directory');

        $themes = [];

        if ($map = directory_map($theme_base_path, 1)) {
            foreach ($map as $theme) {
                $themePath = $theme_base_path . $theme;

                if (@is_file($themePath) || !@is_dir($themePath) || !@file_exists($themePath . '/installer.xml') || !@is_dir($themePath . '/templates')) {
                    continue;
                }

                $themes[$theme] = $theme;
            }
        }

        return $themes;
    }

    public function configurator_ajax()
    {
        $html = null;

        ee()->load->helper(['data_formatting_helper', 'html', 'array', 'form', 'array']);

        $field_id = element('opt_field_name', $_POST);
        $field_id_name = 'field_id_' . $field_id;
        $p_opt = element($field_id_name, $_POST, []);
        $html = null;
        $options = [];
        $prices = [];
        $saved_all_values = [];
        $saved_option_value = [];
        $saved_option_label = [];
        $saved_price = [];
        $saved_inventory = [];

        foreach ($p_opt as $key => $value) {
            if (element('options', $value)) {
                $o = element('option', $value['options']);
                if ($o) {
                    foreach ($o as $k => $v) {
                        $price = element($k, $value['options']['price']);
                        if (!$price) {
                            $price = 0;
                        }
                        $options[element('option_group', $value)][] = $v;
                        $prices[element('option_group', $value)][] = $price;
                    }
                }
            }

            if (array_key_exists('option_value', $value)) {
                $price = element('price', $value);
                if (!$price) {
                    $price = 0;
                }
                $saved_all_values[] = element('all_values', $value);
                $saved_option_value[] = element('option_value', $value);
                $saved_option_label[] = element('option_name', $value);
                $saved_price[] = $price;
                $saved_inventory[] = element('inventory', $value);
            }
        }

        $final_options = cartesian($options);
        $final_prices = cartesian($prices);
        $prices = cartesian_to_price($final_prices);
        $all_values = [];
        $option_value = [];
        $option_label = [];
        $price = [];
        $inventory = [];

        foreach ($final_options as $k => $v) {
            if (!$cost = element($k, $prices)) {
                $cost = 0;
            }

            $all_values[$k] = base64_encode(serialize($v));
            $option_value[$k] = ''; // implode("-",$v); // sku
            $option_label[$k] = ''; // ucwords(str_replace("_" , " ", implode(", ",$v))); // name
            $price[$k] = $cost;
            $inventory[$k] = '';
        }

        if (count($saved_all_values) && !empty($saved_all_values) && is_array($saved_all_values)) {
            $copy = $final_options;

            foreach ($saved_all_values as $key => $value) {
                $opt = @unserialize(base64_decode($value));

                if (is_array($copy) && is_array($opt)) {
                    foreach ($copy as $k => $v) {
                        $temp_arr = array_intersect_assoc($opt, $v);

                        if (count($temp_arr) == count($opt)) {
                            $all_values[$k] = base64_encode(serialize($v));
                            $option_value[$k] = element($key, $saved_option_value);
                            $option_label[$k] = element($key, $saved_option_label);
                            // $price[$k] = element($key, $saved_price);
                            $inventory[$k] = element($key, $saved_inventory);
                            unset($copy[$k]);
                        }
                    }
                }
            }
        }

        $data = [
            'all_values' => $all_values,
            'option_value' => $option_value,
            'option_label' => $option_label,
            'price' => $price,
            'inventory' => $inventory,
            'options' => $final_options,
            'field_id' => $field_id,
            'field_id_name' => $field_id_name,
            'show_inventory' => element('show_inventory', $_POST, 0),
        ];

        $html = null;
        $html .= ee()->load->view('configurator', $data, true);

        if (!$html) {
            $html = 'could not be loaded';
        }

        ee()->output->send_ajax_response([
            'success' => $html,
            'CSRF_TOKEN' => ee()->functions->add_form_security_hash('{csrf_token}'),
        ]);
    }

    /**
     * @return string|void
     */
    public function reports()
    {
        if (ee()->input->get('save')) {
            $reports_settings = ee()->input->post('reports_settings');

            if (is_array($reports_settings) && isset($reports_settings['reports'])) {
                $_POST = ['reports' => $reports_settings['reports']];
            } else {
                $_POST = ['reports' => []];
            }

            $_GET['return'] = 'reports';

            $this->quick_save();

            return;
        }

        $this->initialize();

        if (ee()->input->get('entry_id')) {
            ee()->functions->redirect(ee('CP/URL')->make('publish/edit/entry/' . ee()->input->get('entry_id')));
        }

        ee()->load->library('reports');
        ee()->load->library('number');

        if (ee()->input->get_post('report')) {
            ee()->load->library('template_helper');

            ee()->template_helper->reset([
                'base_url' => ee('CP/URL')->make('addons/settings/cartthrob/reports', ['report' => '']),
                'template_key' => 'report',
            ]);

            $data['view'] = ee()->template_helper->cp_render();
        } else {
            if (ee()->input->get('year')) {
                if (ee()->input->get('month')) {
                    if (ee()->input->get('day')) {
                        $name = date('D d', mktime(0, 0, 0, ee()->input->get('month'), ee()->input->get('day'), ee()->input->get('year')));
                        $rows = ee()->reports->get_daily_totals(ee()->input->get('day'), ee()->input->get('month'), ee()->input->get('year'));
                        $overview = lang('narrow_by_order');
                    } else {
                        $name = date('F Y', mktime(0, 0, 0, ee()->input->get('month'), 1, ee()->input->get('year')));
                        $rows = ee()->reports->get_monthly_totals(ee()->input->get('month'), ee()->input->get('year'));
                        $overview = lang('narrow_by_day');
                    }
                } else {
                    $name = ee()->input->get('year');
                    $rows = ee()->reports->get_yearly_totals(ee()->input->get('year'));
                    $overview = lang('narrow_by_month');
                }
            } else {
                $name = ee()->lang->line('reports_order_totals_to_date');
                $rows = ee()->reports->get_all_totals();
                $overview = lang('narrow_by_month');
            }

            if ($rows) {
                ee()->javascript->output('cartthrobChart(' . json_encode($rows) . ', "' . $name . '");');
            }

            $data['view'] = ee()->load->view('reports_home', ['overview' => $overview], true);
        }

        ee()->load->library('table');
        ee()->table->clear();
        ee()->table->set_template(['table_open' => '<table border="0" cellpadding="0" cellspacing="0" class="mainTable padTable">']);

        $data['order_totals'] = ee()->table->generate([
            [lang('order_totals'), lang('amount')],
            [lang('today_sales'), ee()->number->format(ee()->reports->get_current_day_total())],
            [lang('month_sales'), ee()->number->format(ee()->reports->get_current_month_total())],
            [lang('year_sales'), ee()->number->format(ee()->reports->get_current_year_total())],
        ]);
        $data['current_report'] = ee()->input->get_post('report');
        $data['reports'] = ['' => lang('order_totals')];

        if (ee()->config->item('cartthrob:reports')) {
            foreach (ee()->config->item('cartthrob:reports') as $report) {
                $data['reports'][$report['template']] = $report['name'];
            }
        }

        $pluginVars = [
            'cartthrob_mcp' => $this,
            'settings' => [
                'reports_settings' => [
                    'reports' => ee()->config->item('cartthrob:reports'),
                ],
            ],
            'plugin_type' => 'reports',
            'plugins' => [
                [
                    'classname' => 'reports',
                    'title' => 'reports_settings_title',
                    'overview' => 'reports_settings_overview',
                    'settings' => [
                        [
                            'name' => 'reports',
                            'short_name' => 'reports',
                            'type' => 'matrix',
                            'settings' => [
                                [
                                    'name' => 'report_name',
                                    'short_name' => 'name',
                                    'type' => 'text',
                                ],
                                [
                                    'name' => 'report_template',
                                    'short_name' => 'template',
                                    'type' => 'select',
                                    'options' => $this->templates(),
                                ],
                            ],
                        ],
                    ],
                ],
            ],
        ];

        $data['reports_list'] = ee()->load->view('plugin_settings', $pluginVars, true);

        ee()->load->library('javascript');

        ee()->javascript->output('
            $(document).on("change", "select[name=report]", function(){
                $(this).parents("form").submit();
            });
            $("#reports").show();
        ');

        return $this->loadView(__FUNCTION__, $data);
    }

    /**
     * @param bool $setSuccessMsg
     */
    public function quick_save($setSuccessMsg = true)
    {
        $this->initialize();

        $settings = $this->saveSettings($getAllSettings = false);

        // If the finger print method is changed we have to clear all sessions
        if ($this->isSessionFingerprintMethodChanged($settings)) {
            ee()->db->truncate('cartthrob_sessions');
        }

        foreach ($this->prepareData() as $key => $value) {
            $where = [
                'site_id' => ee()->config->item('site_id'),
                '`key`' => $key,
            ];

            switch ($key) {
                case 'cp_menu':
                    $this->toggleCustomKeyActions($value);
                    break;
                case 'channels':
                    $this->installChannels($value);
                    break;
                case 'templates':
                    $this->installTemplates($value);
                    break;
            }

            if (is_array($value)) {
                $row['serialized'] = 1;
                $row['value'] = serialize($value);
            } else {
                $row['serialized'] = 0;
                $row['value'] = $value;
            }

            if (!isset($settings[$key]) || ee()->db->count_all('cartthrob_settings') <= 0) {
                ee()->db->insert('cartthrob_settings', array_merge($row, $where));
            } elseif ($value !== $settings[$key]) {
                ee()->db->update('cartthrob_settings', $row, $where);
            }
        }

        if ($setSuccessMsg) {
            ee()->session->set_flashdata(
                'message_success',
                sprintf('%s %s %s', lang('cartthrob_module_name'), lang('nav_' . ee()->input->get('return')), lang('settings_saved'))
            );
        }

        $return = ee()->input->get('return') ? '/' . ee()->input->get('return', true) : '';

        ee()->functions->redirect(
            ee('CP/URL')->make('addons/settings/cartthrob' . $return)
        );
    }

    // --------------------------------
    //  Validate Settings
    // --------------------------------

    /**
     * Creates setting controls
     *
     * @param string $type text|textarea|radio The type of control that is being output
     * @param string $name input name of the control option
     * @param string $currentValue the current value stored for this input option
     * @param array|bool $options array of options that will be output (for radio, else ignored)
     * @param array $attributes
     * @return string the control's HTML
     */
    public function pluginControlHtml($type, $name, $currentValue, $options = [], $attributes = []): string
    {
        $output = '';

        if (is_array($options)) {
            $newOptions = [];

            foreach ($options as $key => $value) {
                // optgroups
                if (is_array($value)) {
                    $key = lang($key);
                    foreach ($value as $sub => $item) {
                        $newOptions[$key][$sub] = lang($item);
                    }
                } else {
                    $newOptions[$key] = lang($value);
                }
            }

            $options = $newOptions;
        }

        switch ($type) {
            case 'add_to_head':
                $output = '';

                if (strpos($currentValue, '<script') !== false) {
                    ee()->cp->add_to_foot($currentValue);
                } else {
                    ee()->cp->add_to_head($currentValue);
                }
                break;
            case 'add_to_foot':
                $output = '';
                ee()->cp->add_to_foot($currentValue);
                break;
            case 'note':
                $output = $currentValue;
                break;
            case 'select':
                if (empty($options)) {
                    $attributes['value'] = $currentValue;
                }
                $output = form_dropdown($name, $options, $currentValue, _attributes_to_string($attributes));
                break;
            case 'multiselect':
                $output = form_multiselect($name . '[]', $options, $currentValue, _attributes_to_string($attributes));
                break;
            case 'checkbox':
                if ($attributes) {
                    if (!empty($options['extra'])) {
                        $options['extra'] .= ' ' . _attributes_to_string($attributes);
                    } else {
                        $options['extra'] = _attributes_to_string($attributes);
                    }
                }

                $checked = !empty($current_value);
                $labelText = !empty($options['label']) ? $options['label'] : ee()->lang->line('yes');
                $output = form_checkbox($name, $value = 1, $checked, $options['extra'] ?? '') . '&nbsp;' . form_label($labelText, $name);
                break;
            case 'text':
                $attributes['name'] = $name;
                $attributes['value'] = $currentValue;
                $output = form_input($attributes);
                break;
            case 'textarea':
                $attributes['name'] = $name;
                $attributes['value'] = $currentValue;
                $output = form_textarea($attributes);
                break;
            case 'radio':
                if (empty($options)) {
                    $output .= form_label(form_radio($name, 1, (bool)$currentValue) . '&nbsp;' . ee()->lang->line('yes'), $name, ['class' => 'radio']);
                    $output .= form_label(form_radio($name, 0, (bool)!$currentValue) . '&nbsp;' . ee()->lang->line('no'), $name, ['class' => 'radio']);
                } else {
                    // if is index array
                    if (array_values($options) === $options) {
                        foreach ($options as $option) {
                            $output .= form_label(form_radio($name, $option, ($currentValue === $option)) . '&nbsp;' . $option, $name, ['class' => 'radio']);
                        }
                    } // if associative array
                    else {
                        foreach ($options as $option => $option_name) {
                            $output .= form_label(form_radio($name, $option, ($currentValue === $option)) . '&nbsp;' . lang($option_name), $name, ['class' => 'radio']);
                        }
                    }
                }
                break;
            default:
        }

        return $output;
    }

    // --------------------------------
    //  Export Settings
    // --------------------------------

    public function email_test()
    {
        if (!AJAX_REQUEST) {
            exit;
        }

        if (REQ !== 'CP') {
            exit;
        }

        ee()->load->library('cartthrob_emails');

        $event = ee()->input->post('email_event');
        if (!$event) {
            $emails = ee()->cartthrob_emails->get_email_for_event($event = null, 'open', 'closed');
        } else {
            $emails = ee()->cartthrob_emails->get_email_for_event($event);
        }

        if (!empty($emails)) {
            $test_panel = [
                'inventory' => 5,
                'billing_address' => 'Test Avenue',
                'billing_address2' => 'Apt 1',
                'billing_city' => 'Testville',
                'billing_company' => 'Testco',
                'billing_country' => 'United States',
                'billing_country_code' => 'USA',
                'billing_first_name' => 'Testy',
                'billing_last_name' => 'Testerson',
                'billing_state' => 'MO',
                'billing_zip' => '63303',
                'customer_email' => 'test@yoursite.com',
                'customer_name' => 'Test Testerson',
                'customer_phone' => '555-555-5555',
                'discount' => '0.00',
                'entry_id' => '111',
                'group_id' => '1',
                'member_id' => '1',
                'order_id' => '111',
                'shipping' => '10',
                'shipping_plus_tax' => '10.80',
                'subtotal' => '110.00',
                'subtotal_plus_tax' => '123.45',
                'tax' => '13.45',
                'title' => '111',
                'total' => '123.45',
                'total_cart' => '123.45',
                'transaction_id' => '12345678',
            ];

            foreach ($emails as $emailDetails) {
                ee()->cartthrob_emails->send_email($emailDetails, $test_panel);
            }
        }

        // forces json output
        ee()->output->send_ajax_response(['CSRF_TOKEN' => ee()->functions->add_form_security_hash('{csrf_token}')]);
    }

    // --------------------------------
    //  GET Settings
    // --------------------------------

    public function save_price_modifier_presets_action()
    {
        if (!AJAX_REQUEST) {
            exit;
        }

        if (REQ !== 'CP' && !ee()->security->secure_forms_check(ee()->input->post('csrf_token'))) {
            exit;
        }

        ee()->db
            ->from('cartthrob_settings')
            ->where('`key`', 'price_modifier_presets')
            ->where('site_id', ee()->config->item('site_id'));

        $presets = (ee()->input->post('price_modifier_presets')) ? ee()->input->post('price_modifier_presets', true) : [];
        $value = [];

        foreach ($presets as $preset) {
            if (!is_array($preset['values'])) {
                continue;
            }

            $value[$preset['name']] = $preset['values'];
        }

        $data = [
            'value' => serialize($value),
            'serialized' => 1,
        ];

        if (ee()->db->count_all_results() == 0) {
            $data['site_id'] = ee()->config->item('site_id');
            $data['`key`'] = 'price_modifier_presets';

            ee()->db->insert('cartthrob_settings', $data);
        } else {
            ee()->db->update(
                'cartthrob_settings',
                $data,
                [
                    'site_id' => ee()->config->item('site_id'),
                    '`key`' => 'price_modifier_presets',
                ]
            );
        }

        // forces json output
        ee()->output->send_ajax_response(['CSRF_TOKEN' => ee()->functions->add_form_security_hash('{csrf_token}')]);
    }

    /**
     * @note requires package installer and packages entries model to use.
     *
     * @param array $channels
     */
    public function installChannels(array $channels = [])
    {
        $this->initialize();

        foreach ($this->packageInstaller->packages() as $row_id => $package) {
            if (in_array($row_id, $channels)) {
                continue;
            }

            $this->packageInstaller->removePackage($row_id);
        }

        $this->packageInstaller->installChannels();

        ee()->session->set_flashdata('template_errors', $this->packageInstaller->errors());

        foreach ($this->packageInstaller->installed() as $installed) {
            ee()->logger->developer($installed);
        }

        $this->packageInstaller->reloadConfig();
    }

    /**
     * @note requires package installer and packages entries model to use.
     *
     * @param array $templates
     */
    public function installTemplates(array $templates = [])
    {
        $this->initialize();

        foreach ($this->packageInstaller->packages() as $row_id => $package) {
            if (!in_array($row_id, $templates)) {
                $this->packageInstaller->removePackage($row_id);
            }
        }

        $this->packageInstaller
            ->setTemplatePath(PATH_THIRD . 'cartthrob/installer/templates/')
            ->installTemplates();

        ee()->session->set_flashdata('template_errors', $this->packageInstaller->errors());

        foreach ($this->packageInstaller->installed() as $installed) {
            ee()->logger->developer($installed);
        }

        $this->packageInstaller->reloadConfig();
    }

    // --------------------------------
    //  Get Payment Gateways
    // --------------------------------

    public function install_theme()
    {
        $themes = $this->themes();
        $theme = ee()->input->post('theme');

        if (!in_array($theme, $themes)) {
            show_error(lang('invalid_theme'));
        }

        loadCartThrobPath();

        if (ee()->config->item('cartthrob_third_party_path')) {
            $theme_path = ee()->config->slash_item('cartthrob_third_party_path') . 'installer/' . $theme . '/';
        } else {
            $theme_path = PATH_THIRD . 'cartthrob/third_party/installer/' . $theme . '/';
        }

        ee()->load->library('package_installer', ['xml' => $theme_path . 'installer.xml']);

        ee()->package_installer->set_template_path($theme_path . 'templates/')->install();

        ee()->session->set_flashdata('theme_errors', ee()->package_installer->errors());
        ee()->session->set_flashdata('themes_installed', ee()->package_installer->installed());

        ee()->functions->redirect(ee('CP/URL')->make('addons/settings/cartthrob/installation'));
    }

    public function save_template_variables()
    {
        ee()->session->set_flashdata('template_variables_updated', ee()->package_installer->installed());

        ee()->functions->redirect(ee('CP/URL')->make('addons/settings/cartthrob/installation'));
    }

    public function import_settings()
    {
        $this->initialize();

        if (isset($_FILES['settings']) && $_FILES['settings']['error'] == 0) {
            ee()->load->helper('file');

            if ($new_settings = read_file($_FILES['settings']['tmp_name'])) {
                $_POST = _unserialize($new_settings);
            }

            $_GET['return'] = 'import_export';

            $this->quick_save();
        }

        ee()->functions->redirect(ee('CP/URL')->make('addons/settings/cartthrob/import_export'));
    }

    // --------------------------------
    //  Get Shipping Plugins
    // --------------------------------

    public function set_encryption_key()
    {
        ee()->config->_update_config(['encryption_key' => ee()->input->post('encryption_key', true)]);

        ee()->functions->redirect(ee('CP/URL')->make('addons/settings/cartthrob'));
    }

    /**
     * Checks to see if any fields are missing. If the fields are missing, The "missing" array is returned, and 'valid' boolean is false.
     *
     * @return array
     */
    public function validate_settings()
    {
        $valid = true;
        $missing = [];

        foreach ($this->requiredSettings as $required) {
            if (!ee()->input->post($required)) {
                $missing[] = $required;
                $valid = false;
            }
        }

        return ['valid' => $valid, 'missing' => $missing];
    }

    /// BEGIN  TAXES ****************************************

    /**
     * Generates & downloads a file called "cartthrob_settings.txt" that contains current settings for CartThrob
     * Useful for backup and transfer.
     */
    public function export_settings()
    {
        $this->initialize();

        ee()->load->helper('download');

        force_download('cartthrob_settings.txt', serialize($this->settings()));
    }

    /**
     * @return string
     */
    public function taxes()
    {
        ee()->load->library('pagination');
        ee()->load->model('tax_model');

        if (!$offset = ee()->input->get_post('rownum')) {
            $offset = 0;
        }

        ee()->pagination->initialize($this->pagination_config('taxes', ee()->db->count_all('cartthrob_tax'), $limit = '50'));

        return $this->loadView(
            __FUNCTION__,
            [
                'taxes' => ee()->tax_model->read(null, $limit, $offset),
                'pagination' => ee()->pagination->create_links(),
                'form_open' => form_open(ee('CP/URL')->make('addons/settings/cartthrob/quick_save', ['return' => 'taxes'])),
                'add_href' => ee('CP/URL')->make('addons/settings/cartthrob/add_tax'),
            ]
        );
    }

    private function pagination_config($method, $totalRows, $perPage = 50)
    {
        return [
            'base_url' => ee('CP/URL')->make('addons/settings/cartthrob/' . $method),
            'total_rows' => $totalRows,
            'per_page' => $perPage,
            'page_query_string' => true,
            'query_string_segment' => 'rownum',
            'full_tag_open' => '<p id="paginationLinks">',
            'full_tag_close' => '</p>',
            'prev_link' => '<img src="' . ee()->cp->cp_theme_url . 'images/pagination_prev_button.gif" width="13" height="13" alt="<" />',
            'next_link' => '<img src="' . ee()->cp->cp_theme_url . 'images/pagination_next_button.gif" width="13" height="13" alt=">" />',
            'first_link' => '<img src="' . ee()->cp->cp_theme_url . 'images/pagination_first_button.gif" width="13" height="13" alt="< <" />',
            'last_link' => '<img src="' . ee()->cp->cp_theme_url . 'images/pagination_last_button.gif" width="13" height="13" alt="> >" />',
        ];
    }

    /**
     * @return string
     */
    public function add_tax()
    {
        return $this->loadView(
            __FUNCTION__,
            ['form_edit' => form_open(ee('CP/URL')->make('addons/settings/cartthrob/form_update_tax', ['return' => 'taxes']))]
        );
    }

    /**
     * @return string
     */
    public function edit_tax()
    {
        ee()->load->model('tax_model');

        return $this->loadView(
            __FUNCTION__,
            [
                'tax' => ee()->tax_model->read(ee()->input->get('id')),
                'form_edit' => form_open(ee('CP/URL')->make('addons/settings/cartthrob/form_update_tax', ['return' => 'taxes'])),
            ]
        );
    }

    /**
     * @return string
     */
    public function delete_tax()
    {
        ee()->load->model('tax_model');

        return $this->loadView(
            __FUNCTION__,
            [
                'tax' => ee()->tax_model->read(ee()->input->get('id')),
                'form_edit' => form_open(ee('CP/URL')->make('addons/settings/cartthrob/form_update_tax', ['return' => 'taxes'])),
            ]
        );
    }

    /// END TAXES ****************************************

    /// START BETA ****************************************

    public function form_update_beta()
    {
        $this->initialize();
    }

    /// END BETA ****************************************

    public function form_update_tax()
    {
        // @TODO add tax
        $this->initialize();
        ee()->load->model('tax_model');
        $data = [];

        foreach (array_keys($_POST) as $key) {
            if (!in_array($key, $this->remove_keys) &&
                !preg_match('/^(Cartthrob_.*?_settings|product_weblogs|product_weblog_fields|default_location)_.*/', $key)
            ) {
                $data[$key] = ee()->input->post($key, true);
            }
        }

        if (!ee()->input->post('id')) {
            $data['id'] = ee()->input->post('add_id');
            ee()->tax_model->create($data);
        } elseif (ee()->input->post('delete_tax')) {
            ee()->tax_model->delete(ee()->input->post('id'));
        } else {
            ee()->tax_model->update($data, ee()->input->post('id'));
        }

        ee()->session->set_flashdata(
            'message_success',
            sprintf('%s %s %s', lang('cartthrob_module_name'), lang('nav_' . ee()->input->get('return')), lang('settings_saved'))
        );

        ee()->functions->redirect(ee('CP/URL')->make('addons/settings/cartthrob/' . ee()->input->get('return', true)));
    }

    /**
     * package filter
     *
     * used in package fieldtype to process entry filter ajax request
     */
    public function package_filter()
    {
        if (!AJAX_REQUEST) {
            show_error(ee()->lang->line('unauthorized_access'));
        }

        $channels = ee()->config->item('cartthrob:product_channels');

        ee()->load->model('search_model');

        if (ee()->input->get_post('channel_id') && ee()->input->get_post('channel_id') != 'null') {
            $channels = ee()->input->get_post('channel_id');
        }

        $keywords = ee()->input->get_post('keywords');

        ee()->load->model('cartthrob_entries_model');

        // typed in an entry_id
        if (is_numeric($keywords)) {
            $entry = [];

            if ($entry = ee()->cartthrob_entries_model->entry($keywords)) {
                $entries[] = $entry;
            }

            $entries = $entry;
        } else {
            ee()->load->helper('text');

            /** @var CI_DB_result $query */
            $query = ee()->db
                ->select('entry_id')
                ->distinct()
                ->from('exp_channel_titles')
                ->where('site_id', ee()->config->item('site_id'))
                ->where_in('channel_id', $channels)
                ->get();

            ee()->load->library('data_filter');

            $entryIds = ee()->data_filter->key_values($query->result_array(), 'entry_id');
            $entries = ee()->cartthrob_entries_model->entries($entryIds);
        }

        ee()->load->model(['product_model', 'cartthrob_field_model']);

        foreach ($entries as &$entry) {
            $entry['price_modifiers'] = ee()->product_model->get_all_price_modifiers($entry['entry_id']);

            foreach ($entry['price_modifiers'] as $price_modifier => $options) {
                $entry['price_modifiers'][$price_modifier]['label'] = ee()->cartthrob_field_model->get_field_label(ee()->cartthrob_field_model->get_field_id($price_modifier));
            }
        }

        ee()->output->send_ajax_response([
            'entries' => $entries,
            'id' => ee()->input->get_post('filter_id'),
        ]);
    }

    public function crontabulous_get_pending_subscriptions()
    {
        ee()->load->library(['crontabulous_responder', 'paths']);

        ee()->crontabulous_responder->set_private_key(ee()->cartthrob->store->config('crontabulous_api_key'));

        if (ee()->crontabulous_responder->validate_request()) {
            ee()->load->model('subscription_model');

            /** @var CI_DB_result $query */
            $query = ee()->subscription_model->get_pending_subscriptions();

            foreach ($query->result() as $row) {
                // add the process subscription url for this pending subscription to the queue
                ee()->crontabulous_responder->enqueue(
                    htmlentities(
                        ee()->paths->build_action_url('Cartthrob_mcp', 'crontabulous_process_subscription', ['id' => $row->id]),
                        $quote_style = ENT_QUOTES,
                        $charset = 'UTF-8',
                        $double_encode = false
                    )
                );
            }
        }

        ee()->crontabulous_responder->send_response();
    }

    public function crontabulous_process_subscription()
    {
        ee()->load->library(['crontabulous_responder', 'paths']);

        ee()->crontabulous_responder->set_private_key(ee()->cartthrob->store->config('crontabulous_api_key'));

        if (ee()->crontabulous_responder->validate_request()) {
            $this->process_subscription(ee()->input->get('id'));
        }

        ee()->crontabulous_responder->send_response();
    }

    /**
     * @param $subscriptionId
     * @return mixed
     */
    public function process_subscription($subscriptionId)
    {
        if (!is_numeric($subscriptionId)) {
            exit;
        }

        ee()->load->library('cartthrob_payments');
        ee()->load->model(['vault_model', 'subscription_model', 'order_model', 'customer_model']);

        return ee()->cartthrob_payments->apply('subscriptions', 'process_subscription', $subscriptionId);
    }

    /**
     * This method is accessed in several ways
     *
     * a) cron_subscriptions.sh
     * b) cron_subsciptions.pl
     * c) extload.php
     * d) url
     *
     * @param bool $getIds
     */
    public function process_subscriptions($getIds = false)
    {
        ee()->load->library('cartthrob_payments');
        ee()->load->model(['vault_model', 'subscription_model', 'order_model', 'customer_model']);

        // get subscriptions that are due for billing and/or expired
        /** @var CI_DB_result $query */
        $query = ee()->subscription_model->get_pending_subscriptions();
        $subscriptions = $query->result_array();
        $query->free_result();

        // return a space delimited list of subscription ids which the shell script will use to process subs individually
        if ($getIds) {
            $subscriptionIds = [];

            foreach ($subscriptions as $subscription) {
                $subscriptionIds[] = $subscription['id'];
            }

            exit(implode(' ', $subscriptionIds));
        }

        // extload
        // loop through subscriptions and process each one via php cli and passthru
        if (@php_sapi_name() === 'cli') {
            if (empty($_SERVER['argv'])) {
                exit;
            }

            $args = $_SERVER['argv'];

            // add the php command
            array_unshift($args, 'php');

            // remove the current cron command
            array_pop($args);

            // add the process_subscription cron command
            array_push($args, 'process_subscription');

            foreach ($subscriptions as $subscription) {
                // add the id to the command
                array_push($args, $subscription['id']);
                passthru(implode(' ', $args));
                array_pop($args);
            }

            exit;
        }

        // this is the url interface, process ONE subscription
        if ($subscription = array_shift($subscriptions)) {
            $this->process_subscription($subscription['id']);
        }
    }

    /**
     * Used by the manual processing in the CP
     */
    public function ajax_process_subscription()
    {
        $subscription_id = ee()->input->get_post('subscription_id');

        $this->process_subscription($subscription_id);

        exit;
    }

    public function ajax_get_pending_subscriptions()
    {
        if (!ee()->input->is_ajax_request()) {
            return show_404();
        }

        ee()->load->model('subscription_model');

        /** @var CI_DB_result $query */
        $query = ee()->subscription_model->get_pending_subscriptions();

        $data = [
            'count' => $query->num_rows(),
            'subscriptions' => [],
        ];

        foreach ($query->result() as $row) {
            $data['subscriptions'][] = $row->id;
        }

        $query->free_result();

        ee()->output->send_ajax_response($data);

        exit;
    }

    public function garbage_collection()
    {
        header('X-Robots-Tag: noindex');

        ee()->db->where('expires <', @time())->delete('cartthrob_sessions');

        ee()->db->query(
            'DELETE `' . ee()->db->dbprefix('cartthrob_cart') . '`
             FROM `' . ee()->db->dbprefix('cartthrob_cart') . '`
             LEFT OUTER JOIN `' . ee()->db->dbprefix('cartthrob_sessions') . '`
             ON `' . ee()->db->dbprefix('cartthrob_cart') . '`.`id` = `' . ee()->db->dbprefix('cartthrob_sessions') . '`.`cart_id`
             WHERE `' . ee()->db->dbprefix('cartthrob_sessions') . '`.`cart_id` IS NULL'
        );
    }

    /**
     * @param $content
     * @param string $tag
     * @param string $attributes
     * @return string
     */
    protected function html($content, $tag = 'p', $attributes = ''): string
    {
        if (is_array($attributes)) {
            $attributes = _parse_attributes($attributes);
        }

        return sprintf('<%s%s>%s</%s>', $tag, $attributes, $content, $tag);
    }

    /**
     * @param $type
     * @return Collection
     * @deprecated 6.0.0 Use PluginService instead
     */
    private function loadLegacyPlugins($type): Collection
    {
        ee()->load->helper(['file', 'data_formatting']);

        $plugins = new Collection();
        $paths[] = CARTTHROB_PATH . 'plugins/' . $type . '/';

        if (ee()->config->item('cartthrob_third_party_path')) {
            $paths[] = rtrim(ee()->config->item('cartthrob_third_party_path'), '/') . '/' . $type . '_plugins/';
        } else {
            $paths[] = PATH_THIRD . 'cartthrob/third_party/' . $type . '_plugins/';
        }

        foreach ($paths as $path) {
            if (!is_dir($path)) {
                continue;
            }

            foreach (get_filenames($path, true) as $file) {
                if (!preg_match('/^Cartthrob_/', basename($file, '.php'))) {
                    continue;
                }

                $className = basename($file, '.php');

                $this->loadPluginLang($className, $path);

                $pluginInfo = get_class_vars($className);
                $pluginInfo['classname'] = $className;
                $pluginInfo['settings'] = $this->loadPluginSettings($className, $pluginInfo['settings']);

                $plugins->push($pluginInfo);
            }
        }

        return $plugins;
    }

    /**
     * @param string $className
     * @param array $pluginSettings
     * @return array
     */
    private function loadPluginSettings(string $className, array $pluginSettings): array
    {
        $sysSettings = $this->settings();

        foreach ($pluginSettings as $key => $setting) {
            // retrieve the current set value of the field
            $currentValue = $sysSettings[$className . '_settings'][$setting['short_name']] ?? false;
            // set the value to the default value if there is no set value and the default value is defined
            $currentValue = ($currentValue === false && isset($setting['default'])) ? $setting['default'] : $currentValue;

            if ($setting['type'] == 'matrix') {
                if (!is_array($currentValue) || !count($currentValue)) {
                    $currentValues = [[]];

                    foreach ($setting['settings'] as $matrixSetting) {
                        $currentValues[0][$matrixSetting['short_name']] = $matrixSetting['default'] ?? '';
                    }
                } else {
                    $currentValues = $currentValue;
                }
            } else {
                $currentValues = $currentValue;
            }

            $pluginSettings[$key]['default'] = $currentValues;
        }

        return $pluginSettings;
    }

    /**
     * @param Collection $loadedPlugins
     * @param $type
     */
    private function loadPluginsByType(Collection $loadedPlugins, $type): void
    {
        $baseClassesForType = [
            'discount' => Cartthrob_discount::class,
            'payment' => Cartthrob_payment_gateway::class,
            'price' => Cartthrob_price::class,
            'shipping' => Cartthrob_shipping::class,
            'tax' => Cartthrob_tax::class,
        ];

        foreach (get_declared_classes() as $className) {
            if (is_subclass_of($className, $baseClassesForType[$type]) && !in_array($className, $loadedPlugins->pluck('classname')->toArray())) {
                $data = get_class_vars($className);
                $data['classname'] = $className;
                $data['settings'] = $this->loadPluginSettings($className, $data['settings']);

                try {
                    $reflection = new ReflectionClass($className);
                    $path = $reflection->getFileName();

                    $this->loadPluginLang($className, dirname($path) . '/');

                    $loadedPlugins->push($data);
                } catch (ReflectionException $e) {
                    continue;
                }
            }
        }

        foreach (ee('cartthrob:PluginService')->getShipping() as $shipping) {
            $className = get_class($shipping);
            $data = get_class_vars($className);
            $data['classname'] = $className;

            unset($data['settings']);

            $loadedPlugins->push($data);
        }
    }

    /**
     * @param string $className
     * @param $path
     */
    private function loadPluginLang(string $className, $path): void
    {
        $language = set(ee()->session->userdata('language'), ee()->input->cookie('language'), ee()->config->item('deft_lang'), 'english');
        $formattedClassName = strtolower($className);

        if (file_exists(PATH_THIRD . 'cartthrob/language/' . $language . '/' . $formattedClassName . '_lang.php')) {
            ee()->lang->loadfile($formattedClassName, $package = 'cartthrob', $show_errors = false);
        } elseif (file_exists($path . '../language/' . $language . '/' . $formattedClassName . '_lang.php')) {
            ee()->lang->load(
                $formattedClassName,
                $language,
                $return = false,
                $add_suffix = true,
                $alt_path = $path . '../',
                $show_errors = false
            );
        } elseif (file_exists($path . 'language/' . $language . '/' . $formattedClassName . '_lang.php')) {
            ee()->lang->load(
                $formattedClassName,
                $language,
                $return = false,
                $add_suffix = true,
                $alt_path = $path,
                $show_errors = false
            );
        }
    }

    /**
     * @return array
     */
    private function prepareData(): array
    {
        $data = [];

        foreach (array_keys($_POST) as $key) {
            if (in_array($key, $this->remove_keys) || preg_match('/^(Cartthrob_.*?_settings|product_weblogs|product_weblog_fields|default_location|tax_settings)_.*/', $key)) {
                continue;
            }

            $data[$key] = ee()->input->post($key);
        }

        return $data;
    }

    /**
     * @param array $settings
     * @return bool
     */
    private function isSessionFingerprintMethodChanged(array $settings): bool
    {
        return isset($_POST['session_fingerprint_method']) && isset($settings['session_fingerprint_method']) && $_POST['session_fingerprint_method'] != $settings['session_fingerprint_method'];
    }

    /**
     * @param $value
     */
    private function toggleCustomKeyActions($value): void
    {
        $isInstalled = (bool)ee()->db
            ->where('class', 'Cartthrob_ext')
            ->where('hook', 'cp_menu_array')
            ->count_all_results('extensions');

        if ($value) {
            if (!$isInstalled) {
                ee()->db->insert('extensions', [
                    'class' => 'Cartthrob_ext',
                    'method' => 'cp_menu_array',
                    'hook' => 'cp_menu_array',
                    'settings' => '',
                    'priority' => 10,
                    'version' => $this->version(),
                    'enabled' => 'y',
                ]);
            }
        } elseif ($isInstalled) {
            ee()->db
                ->where('class', 'Cartthrob_ext')
                ->where('hook', 'cp_menu_array')
                ->delete('extensions');
        }
    }
}
