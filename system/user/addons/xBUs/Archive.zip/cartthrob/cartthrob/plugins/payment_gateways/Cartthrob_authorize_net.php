<?php

use Academe\AuthorizeNet\Request\AbstractRequest;
use CartThrob\Transactions\TransactionState;
use Omnipay\AuthorizeNetApi\ApiGateway as OmnipayGateway;
use Omnipay\AuthorizeNetApi\Message\AuthorizeResponse;
use Omnipay\Common\CreditCard;
use Omnipay\Omnipay;

class Cartthrob_authorize_net extends Cartthrob_payment_gateway
{
    const DEFAULT_ERROR_MESSAGE = 'authorize_net_unknown_error';

    /** @var string */
    public $title = 'authorize_net_title';

    /** @var string */
    public $overview = 'authorize_net_overview';

    /** @var array */
    public $settings = [
        [
            'name' => 'mode',
            'short_name' => 'mode',
            'type' => 'select',
            'default' => 'test',
            'options' => [
                'test' => 'authorize_net_mode_test',
                'live' => 'authorize_net_mode_live',
            ],
        ],
        [
            'name' => 'authorize_net_api_login_id_test',
            'short_name' => 'api_login_id_test',
            'type' => 'text',
        ],
        [
            'name' => 'authorize_net_transaction_key_test',
            'short_name' => 'api_transaction_key_test',
            'type' => 'text',
        ],
        [
            'name' => 'authorize_net_public_client_key_test',
            'short_name' => 'api_public_client_key_test',
            'type' => 'text',
        ],
        [
            'name' => 'authorize_net_api_login_id_live',
            'short_name' => 'api_login_id_live',
            'type' => 'text',
        ],
        [
            'name' => 'authorize_net_transaction_key_live',
            'short_name' => 'api_transaction_key_live',
            'type' => 'text',
        ],
        [
            'name' => 'authorize_net_public_client_key_live',
            'short_name' => 'api_public_client_key_live',
            'type' => 'text',
        ],
        [
            'name' => 'authorize_net_capture',
            'short_name' => 'authorize_net_capture',
            'type' => 'select',
            'default' => 'capture',
            'options' => [
                'capture' => 'authorize_net_auth_and_capture',
                'authorize' => 'authorize_net_auth_only',
            ],
            'note' => 'authorize_net_options',
        ],
    ];

    /** @var array */
    public $nameless_fields = [
        'credit_card_number',
        'CVV2',
        'expiration_year',
        'expiration_month',
    ];

    /** @var array */
    public $fields = [
        'first_name',
        'last_name',
        'address',
        'address2',
        'city',
        'state',
        'zip',
        'phone',
        'email_address',
        'shipping_first_name',
        'shipping_last_name',
        'shipping_address',
        'shipping_address2',
        'shipping_city',
        'shipping_state',
        'shipping_zip',
        'card_type',
        'credit_card_number',
        'CVV2',
        'expiration_year',
        'expiration_month',
    ];

    /** @var OmnipayGateway */
    protected $omnipayGateway;

    public function initialize()
    {
        ee()->load->library('paths');

        $this->omnipayGateway = Omnipay::create('AuthorizeNetApi_Api');

        $mode = $this->plugin_settings('mode');

        if ($mode === 'live') {
            $this->form_extra .= '<script type="text/javascript" src="https://js.authorize.net/v1/Accept.js" charset="utf-8"></script>';
        } else {
            $this->omnipayGateway->setTestMode(true);
            $this->form_extra .= '<script type="text/javascript" src="https://jstest.authorize.net/v1/Accept.js" charset="utf-8"></script>';
        }

        $this->omnipayGateway->setAuthName($this->plugin_settings('api_login_id_' . $mode));
        $this->omnipayGateway->setTransactionKey($this->plugin_settings('api_transaction_key_' . $mode));

        $this->form_extra .= <<<EOS
<script type="text/javascript">
    CartthrobTokenizer.onSubmit(function () {
        var data = {
            authData: {
                clientKey: "{$this->plugin_settings('api_public_client_key_' . $mode)}",
                apiLoginID: "{$this->plugin_settings('api_login_id_' . $mode)}"  
            },
            cardData: {
                cardNumber: CartthrobTokenizer.val('#credit_card_number'),
                month: CartthrobTokenizer.val('#expiration_month'),
                year: CartthrobTokenizer.val('#expiration_year'),
                cardCode: CartthrobTokenizer.val('#CVV2')
            }
        };

        Accept.dispatchData(data, function (response) {
            if (response.messages.resultCode === 'Error') {
                return CartthrobTokenizer.error(response.messages.message[0].text);
            }

            CartthrobTokenizer
                .addHidden('opaqueDataDescriptor', response.opaqueData.dataDescriptor)
                .addHidden('opaqueDataValue', response.opaqueData.dataValue);

            CartthrobTokenizer.success(response.messages.message[0].text);
        });
    });
    // CartthrobTokenizer.onError(function () {});
    // CartthrobTokenizer.onSuccess(function () {});
</script>
EOS;
    }

    /**
     * @return TransactionState
     */
    public function charge()
    {
        $params = [
            'amount' => $this->total(),
            'currency' => strtolower(($this->order('currency_code') ? $this->order('currency_code') : 'USD')),
            'invoiceNumber' => $this->order('title'),
            'description' => $this->order('title') . ' (' . $this->orderId() . ')',
        ];

        // if there's no opaque Authorize.net tokens it means that the end user doesn't have javascript enabled
        if (!ee()->input->post('opaqueDataDescriptor') && !ee()->input->post('opaqueDataValue')) {
            return $this->fail(ee()->lang->line('authorize_net_javascript_required'));
        } else {
            $params['opaqueDataDescriptor'] = ee()->input->post('opaqueDataDescriptor');
            $params['opaqueDataValue'] = ee()->input->post('opaqueDataValue');
        }

        $customerInformation = [];

        /*** Billing Information ***/
        // billing first name
        if (ee()->input->post('first_name')) {
            $customerInformation['billingFirstName'] = ee()->input->post('first_name');
        }
        // billing last name
        if (ee()->input->post('last_name')) {
            $customerInformation['billingLastName'] = ee()->input->post('last_name');
        }
        // billing address
        if (ee()->input->post('address')) {
            $customerInformation['billingAddress1'] = ee()->input->post('address');
        }
        // billing city
        if (ee()->input->post('city')) {
            $customerInformation['billingCity'] = ee()->input->post('city');
        }
        // billing state
        if (ee()->input->post('state')) {
            $customerInformation['billingState'] = ee()->input->post('state');
        }
        // billing zip
        if (ee()->input->post('zip')) {
            $customerInformation['billingPostcode'] = ee()->input->post('zip');
        }
        // email address
        if (ee()->input->post('email_address')) {
            $customerInformation['email'] = ee()->input->post('email_address');
        }
        // email address
        if (ee()->input->post('phone')) {
            $customerInformation['billingPhone'] = ee()->input->post('phone');
        }

        /*** Shipping Information ***/
        // shipping first name
        if (ee()->input->post('shipping_first_name')) {
            $customerInformation['shippingFirstName'] = ee()->input->post('shipping_first_name');
        }
        // shipping last name
        if (ee()->input->post('shipping_last_name')) {
            $customerInformation['shippingLastName'] = ee()->input->post('shipping_last_name');
        }
        // shipping address
        if (ee()->input->post('shipping_address')) {
            $customerInformation['shippingAddress1'] = ee()->input->post('shipping_address');
        }
        // shipping city
        if (ee()->input->post('shipping_city')) {
            $customerInformation['shippingCity'] = ee()->input->post('shipping_city');
        }
        // shipping state
        if (ee()->input->post('shipping_state')) {
            $customerInformation['shippingState'] = ee()->input->post('shipping_state');
        }
        // shipping zip
        if (ee()->input->post('shipping_zip')) {
            $customerInformation['shippingPostcode'] = ee()->input->post('shipping_zip');
        }

        $params['card'] = new CreditCard($customerInformation);

        try {
            $auth_capture = $this->plugin_settings('authorize_net_capture');
            if ($auth_capture == 'authorize') {
                /** @var AuthorizeResponse $response */
                $response = $this->createRequest('authorize', $params)->send();
            } else {
                /** @var AuthorizeResponse $response */
                $response = $this->createRequest('purchase', $params)->send();
            }

            if (!$response->isSuccessful()) {
                return $this->fail($response->getMessage());
            }

            return $this->authorize($response->getTransactionReference());
        } catch (Exception $e) {
            return $this->fail($e->getMessage());
        }
    }

    /**
     * @param $transactionId
     * @param $amount
     * @param $lastFour
     * @return TransactionState
     */
    public function refund($transactionId, $amount, $lastFour)
    {
        try {
            $response = $this->omnipayGateway->refund(['transactionReference' => $transactionId])->send();

            if (!$response->isSuccessful()) {
                return $this->fail($response->getMessage());
            }

            return $this->authorize($response->getTransactionReference());
        } catch (\Exception $e) {
            return $this->fail($e->getMessage());
        }
    }

    /**
     * @param string $method
     * @param array $params
     * @return AbstractRequest
     */
    protected function createRequest(string $method, array $params)
    {
        /** @var AbstractRequest $request */
        $request = $this->omnipayGateway->$method($params);

        return $request;
    }
}
