<?php

if (!defined('CARTTHROB_PATH')) {
    Cartthrob_core::core_error('No direct script access allowed');
}

use CartThrob\Math\Number;

class Cartthrob_discount_amount_off extends Cartthrob_discount
{
    public $title = 'amount_off';

    public $settings = [
        [
            'name' => 'amount_off',
            'short_name' => 'amount_off',
            'note' => 'amount_off_note',
            'type' => 'text',
        ],
    ];

    public function get_discount()
    {
        return abs(Number::sanitize($this->plugin_settings('amount_off')));
    }
}
