<?php

class Cartthrob_tax_digital_river extends Cartthrob_tax
{
    public $title = 'digital_river_tax';
    public $note = 'digital_river_tax_note';

    /**
     * @var float
     */
    protected $rate;

    public function initialize($params = [], $defaults = [])
    {
        parent::initialize($params, $defaults);

        $this->rate = ee()->cartthrob->cart->custom_data(Cartthrob_digital_river::TAX_RATE, 0);
    }

    public function get_tax($price)
    {
        return $this->rate * $price;
    }

    public function tax_name()
    {
        return ee()->lang->line($this->title);
    }

    public function tax_rate()
    {
        return $this->rate ?? 0;
    }

    public function tax_shipping()
    {
        return false;
    }
}
