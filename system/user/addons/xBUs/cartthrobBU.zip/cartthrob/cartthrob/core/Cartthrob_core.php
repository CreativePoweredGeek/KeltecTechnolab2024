<?php

use CartThrob\Math\Number;
use CartThrob\Math\Round;

if (!defined('CARTTHROB_PATH')) {
    Cartthrob_core::core_error('No direct script access allowed');
}

abstract class Cartthrob_core
{
    public static $_drivers = ['core', 'payment'];
    public static $_plugins = ['shipping', 'discount', 'price', 'tax'];
    public static $_utilities = ['registered_discount'];
    public static $_plugin_paths = [];
    /** @var Cartthrob_cart */
    public $cart;
    /** @var Cartthrob_store */
    public $store;
    /** @var Cartthrob_hooks */
    public $hooks;
    public $cart_defaults = [];
    public $item_defaults = [];
    public $product_defaults = [];
    public $customer_info_defaults = [];
    protected $config = [];
    private $cache;
    private $lang = [];
    private $errors = [];

    /* inherited methods */

    public static function instance($driver, $params = [])
    {
        if (empty($driver)) {
            Cartthrob_core::core_error('No driver specified.');
        }

        spl_autoload_register('Cartthrob_core::autoload');

        $driver = 'Cartthrob_core_' . $driver;

        $instance = new $driver($params);

        if (isset($params['config'])) {
            $instance->config = $params['config'];
        }

        // the sequence is important here!

        $instance->set_child('hooks', $instance->hooks);

        $instance->set_child('store');

        $cart = (isset($params['cart'])) ? $params['cart'] : [];

        $instance->set_child('cart', $cart);

        spl_autoload_unregister('Cartthrob_core::autoload');

        return $instance;
    }

    /**
     * @param $error
     */
    public static function core_error($error)
    {
        trigger_error($error);
    }

    public static function add_plugin_path($type, $path)
    {
        if (!isset(self::$_plugin_paths[$type]) || !is_array(self::$_plugin_paths[$type])) {
            self::$_plugin_paths[$type] = [];
        }

        if (!in_array($path, self::$_plugin_paths[$type])) {
            self::$_plugin_paths[$type][] = $path;
        }
    }

    public static function autoload($class)
    {
        if (strpos($class, 'Cartthrob_') !== 0) {
            return;
        }

        $short_class = Cartthrob_core::get_class($class);

        // grab first "node" of class name
        $parts = explode('_', $short_class);
        $type = current($parts);

        $class = 'Cartthrob_' . $short_class;

        if (in_array($short_class, self::$_utilities)) {
            $paths = [CARTTHROB_CORE_PATH . "Cartthrob_{$short_class}.php"];
        } else {
            $paths = [CARTTHROB_CORE_PATH . "Cartthrob_{$type}.php"];

            if (in_array($type, Cartthrob_core::$_drivers)) {
                $paths[] = CARTTHROB_DRIVER_PATH . "{$type}/{$class}.php";
            } else {
                if (in_array($type, Cartthrob_core::$_plugins)) {
                    $path_added = false;

                    if (isset(self::$_plugin_paths[$type]) && is_array(self::$_plugin_paths[$type])) {
                        foreach (self::$_plugin_paths[$type] as $path) {
                            if (file_exists($path . "{$class}.php")) {
                                $path_added = true;
                                $paths[] = $path . "{$class}.php";
                                break;
                            }
                        }
                    }

                    if (!$path_added) {
                        $paths[] = CARTTHROB_PLUGIN_PATH . "{$type}/{$class}.php";
                    }
                } else {
                    if (count($parts) > 1) {
                        $paths[] = CARTTHROB_CORE_PATH . 'Cartthrob_child.php';
                        $paths[] = CARTTHROB_CORE_PATH . "{$type}/{$class}.php";
                    }
                }
            }
        }

        foreach ($paths as $path) {
            if (!file_exists($path)) {
                Cartthrob_core::core_error(sprintf('File %s not found.', basename($path)));
            }

            require_once $path;
        }

        if (!class_exists($class)) {
            Cartthrob_core::core_error(sprintf('Class %s not found.', $class));
        }
    }

    public static function get_class($class)
    {
        if (is_object($class)) {
            $class = get_class($class);
        }

        if (strpos($class, 'Cartthrob_') === 0) {
            $class = substr($class, 10);
        }

        return $class;
    }

    public function config($args = null)
    {
        $args = (is_array($args)) ? $args : func_get_args();

        $config = $this->config;

        foreach ($args as $key) {
            if (isset($config[$key])) {
                $config = $config[$key];
            } else {
                return false;
            }
        }

        return $config;
    }

    public function set_config($key, $value = false)
    {
        if (is_array($key)) {
            foreach ($key as $k => $v) {
                $this->config[$k] = $v;
            }
        } else {
            $this->config[$key] = $value;
        }

        return $this;
    }

    public function override_config($override_config)
    {
        if (!is_array($override_config)) {
            return;
        }

        $this->config = $this->array_merge($this->config, $override_config);
    }

    public function array_merge($a, $b)
    {
        foreach ($b as $key => $value) {
            if (is_array($value) && isset($a[$key])) {
                $a[$key] = $this->array_merge($a[$key], $value);
            } else {
                $a[$key] = $value;
            }
        }

        return $a;
    }

    public function cache_pop($key)
    {
        $data = $this->cache($key);

        $this->clear_cache($key);

        return $data;
    }

    public function cache($key)
    {
        if (is_array($key) && $key) {
            $cache = &$this->cache;

            foreach ($key as $value) {
                if (!isset($cache[$value])) {
                    return false;
                }

                $cache = $cache[$value];
            }

            return $cache;
        }

        return (isset($this->cache[$key])) ? $this->cache[$key] : false;
    }

    public function clear_cache($key = false)
    {
        if ($key === false) {
            $this->cache = [];
        } else {
            if (is_array($key) && count($key) > 1) {
                $cache = &$this->cache;

                for ($i = 0; $i < count($key) - 1; $i++) {
                    if (!isset($cache[$key[$i]])) {
                        return;
                    }

                    $cache = &$cache[$key[$i]];
                }

                unset($cache[end($key)]);
            } else {
                unset($this->cache[$key]);
            }
        }
    }

    /* static methods */

    public function set_error($error)
    {
        $this->errors[] = $error;

        return $this;
    }

    public function set_errors($errors)
    {
        $this->errors = $errors;

        return $this;
    }

    public function errors()
    {
        return $this->errors;
    }

    public function clear_errors()
    {
        $this->errors = [];

        return $this;
    }

    public function lang($key)
    {
        return (isset($this->lang[$key])) ? $this->lang[$key] : $key;
    }

    public function set_cache($key, $value)
    {
        if (!is_array($key)) {
            $key = [$key];
        }

        $cache = &$this->cache;

        foreach ($key as $k) {
            if (!isset($cache[$k])) {
                $cache[$k] = null;
            }

            $cache = &$cache[$k];
        }

        $cache = $value;

        return $this;
    }

    /* utilities */

    public function set_child($name, $params = [])
    {
        static $children = ['hooks', 'store', 'cart'];

        if (!in_array($name, $children)) {
            return $this;
        }

        $this->$name = Cartthrob_core::create_child($this, $name, $params);
    }

    /**
     * @param Cartthrob_core $core
     * @param string $className
     * @param array $params
     * @param array $defaults
     * @return Cartthrob_child
     */
    public static function create_child($core, $className, $params = [], $defaults = [])
    {
        spl_autoload_register('Cartthrob_core::autoload');

        $className = 'Cartthrob_' . Cartthrob_core::get_class($className);

        /** @var Cartthrob_child $child */
        $child = new $className();
        $child->set_core($core);
        $child->initialize($params, $defaults);

        spl_autoload_unregister('Cartthrob_core::autoload');

        return $child;
    }

    /**
     * @param null $number
     * @param bool $allow_negative
     * @return float|int
     * @deprecated 6.0.0 Use Math::roundDown(Number::sanitize()) instead
     */
    public function sanitize_integer($number = null, $allow_negative = false)
    {
        ee()->logger->deprecated('5.2.0', 'Use Math::roundDown(Number::sanitize()) instead');

        return Number::sanitize($number);
    }

    /**
     * sanitize_number function
     *
     * @param float $number the number to clean
     * @param bool $allow_negative By default this does not allow negative values. If you need negatives, make sure this is set to TRUE.
     * @param bool $integer By default does not require that the number be an integer
     * @return float|int
     * @deprecated 6.0.0 Use Number::sanitize() instead
     **/
    public function sanitize_number($number = null, $allow_negative = false, $integer = false)
    {
        ee()->logger->deprecated('5.2.0', 'Use Number::sanitize() instead');

        if (is_int($number)) {
            return $number;
        }

        if (is_float($number)) {
            if (!$integer) {
                return $number;
            }

            // it IS an integer but is cast as float
            if ((int)$number === $number) {
                return $number;
            } else {
                $number = (string)$number;
            }
        }

        if (!$number || !is_string($number)) {
            return 0;
        }

        $regex = ($integer) ? '/[^\d]/' : '/[^\d\.]/';

        if ($integer) {
            $number = floor($number);
        }

        if (substr($number, 0, 1) === '-') {
            $number = preg_replace($regex, '', substr($number, 1));

            // GS: This is a very poor choice that allows a negative to just become positive instead of throwing an exception.
            //     Revising in Number::sanitize() to prevent this value direction change that would effect price.
            if ($allow_negative) {
                $number = '-' . $number;
            }
        } else {
            $number = preg_replace($regex, '', $number);
        }

        return floatval($number);
    }

    /**
     * @param $value
     * @return string
     */
    public function round($value): string
    {
        $value = Number::sanitize($value);
        $precision = (int)ee()->cartthrob->store->config('number_format_defaults_decimals');

        return number_format(ee('cartthrob:MoneyService')->round($value), $precision, '.', '');
    }

    public function log($msg)
    {
    }

    public function caller($which = 0)
    {
        $which += 2;

        $backtrace = debug_backtrace();

        return (isset($backtrace[$which])) ? $backtrace[$which] : false;
    }

    /* abstract methods */

    abstract public function get_product($product_id);

    abstract public function get_categories();

    abstract public function save_cart();

    abstract public function validate_coupon_code($coupon_code);
}
