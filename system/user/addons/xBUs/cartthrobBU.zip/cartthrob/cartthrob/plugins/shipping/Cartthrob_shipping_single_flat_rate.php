<?php

use Money\Money;

if (!defined('CARTTHROB_PATH')) {
    Cartthrob_core::core_error('No direct script access allowed');
}

class Cartthrob_shipping_single_flat_rate extends Cartthrob_shipping
{
    public $title = 'single_flat_rate';
    public $settings = [
        [
            'name' => 'rate',
            'short_name' => 'rate',
            'type' => 'text',
        ],
    ];

    /**
     * @return Money
     */
    public function get_shipping(): Money
    {
        return ee('cartthrob:MoneyService')->toMoney($this->plugin_settings('rate'));
    }
}
