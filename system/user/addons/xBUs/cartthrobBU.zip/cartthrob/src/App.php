<?php

namespace CartThrob;

use DI\Container;
use DI\ContainerBuilder;

class App
{
    /** @var Container */
    private static $container;

    public static function container()
    {
        if (!static::$container) {
            $containerBuilder = (new ContainerBuilder())
                ->addDefinitions([
                    \EE_Session::class => function () {
                        return ee()->session;
                    },
                    \EllisLab\ExpressionEngine\Service\Encrypt\Encrypt::class => function () {
                        return ee('Encrypt');
                    },
                ])
                ->useAutowiring(true);

//            $containerBuilder->enableCompilation(SYSPATH . 'user/cache/cartthrob');

            static::$container = $containerBuilder->build();
        }

        return static::$container;
    }
}
