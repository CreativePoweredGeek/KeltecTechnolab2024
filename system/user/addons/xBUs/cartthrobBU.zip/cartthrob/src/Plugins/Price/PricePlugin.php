<?php

namespace CartThrob\Plugins\Price;

use CartThrob\Plugins\Plugin;

abstract class PricePlugin extends Plugin
{
}
