<?php

namespace CartThrob\Plugins\Discount;

use CartThrob\Plugins\Plugin;

abstract class DiscountPlugin extends Plugin
{
}
