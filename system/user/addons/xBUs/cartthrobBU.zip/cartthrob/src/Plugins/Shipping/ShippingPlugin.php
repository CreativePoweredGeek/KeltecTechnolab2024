<?php

namespace CartThrob\Plugins\Shipping;

use CartThrob\Plugins\Plugin;
use Cartthrob_cart;
use Money\Money;

abstract class ShippingPlugin extends Plugin
{
    /**
     * Get the shipping rate for the cart
     *
     * @param Cartthrob_cart $cart
     * @return Money
     */
    abstract public function rate(Cartthrob_cart $cart): Money;

    /**
     * The shipping options for this method
     *
     * @return array
     */
    public function plugin_shipping_options(): array
    {
        return [];
    }
}
