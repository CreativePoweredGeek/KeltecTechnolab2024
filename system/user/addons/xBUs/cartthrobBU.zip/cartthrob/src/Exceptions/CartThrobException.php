<?php

namespace CartThrob\Exceptions;

use Exception;

class CartThrobException extends Exception
{
}
