<?php

namespace CartThrob;

use CartThrob\Math\Number;

trait HandlesSubscriptions
{
    public function update_recurrent_billing_action()
    {
        // currently we allow the customer information stored on file with the recurrent bill to be changed.
        // the actual details of the original order are not changed however.
        // over time we need feedback about what needs to be added / changed in the original order
        // or purchased items when someone decides to update their subscription
        // not all systems allow the sub itself to be updated, but they all allow customer information
        // like credit card numbers to be changed. For our purposes, we're currently only using this
        // as a card data update.

        // @TODO catch the sub id, and order id.

        $total = 0;

        if (!ee()->input->get_post('ACT')) {
            return;
        }

        ee()->cartthrob->save_customer_info();

        ee()->load->library('form_validation');
        ee()->load->library('form_builder');

        ee()->form_builder->set_show_errors(true)
            ->set_success_callback([ee()->cartthrob, 'action_complete'])
            ->set_error_callback([ee()->cartthrob, 'action_complete']);

        if (!ee()->cartthrob->store->config('save_orders')) {
            ee()->form_builder->action_complete();
        }

        ee()->load->library('languages');

        ee()->languages->set_language(ee()->input->post('language', true));

        $not_required = [];
        $required = [];

        if (ee()->input->post('REQ')) {
            $required_string = ee('Security/XSS')->clean(ee('Encrypt')->decode(ee()->input->post('REQ')));

            if (preg_match('/^not (.*)/', $required_string, $matches)) {
                $not_required = explode('|', $matches[1]);
                $required_string = '';
            }

            if ($required_string) {
                $required = explode('|', $required_string);
            }

            unset($required_string);
        }

        $creditCardNumber = sanitize_credit_card_number(ee()->input->post('credit_card_number', true));
        $gateway = ee()->input->post('gateway')
            ? ee('Security/XSS')->clean(ee('Encrypt')->decode(ee()->input->post('gateway')))
            : ee()->cartthrob->store->config('payment_gateway');

        // Load the payment processing plugin that's stored in the extension's settings.
        ee()->load->library('cartthrob_payments');

        if (!ee()->cartthrob_payments->setGateway($gateway)->gateway()) {
            ee()->form_builder
                ->add_error(ee()->lang->line('invalid_payment_gateway'))
                ->action_complete();
        }

        if (ee()->input->post('PR')) {
            $data = ee('Security/XSS')->clean(ee('Encrypt')->decode(ee()->input->post('PR')));

            if ($data == abs(Number::sanitize($data))) { // ignore a non-numeric input
                $total -= $subtotal;
                $subtotal = $data;
                $total += $subtotal;
            }
        } elseif (ee()->input->post('AUP') && bool_string(ee('Encrypt')->decode(ee()->input->post('AUP')))) {
            $total = Number::sanitize(ee()->input->post('price'));
        }

        if (ee()->input->post('SD')) {
            $subId = ee('Security/XSS')->clean(ee('Encrypt')->decode(ee()->input->post('SD')));
        }

        foreach ($not_required as $key) {
            unset($required[array_search($key, $required)]);
        }

        if (!ee()->form_builder->set_required($required)->validate()) {
            ee()->form_builder->action_complete();
        }

        ee()->load->model('order_model');

        ee()->cartthrob->cart->set_order(ee()->order_model->order_data_array());
        ee()->cartthrob_payments->setTotal($total);
        ee()->cartthrob->cart->save();

        /** @var TransactionState $state */
        $state = ee()->cartthrob_payments->updateRecurrentBilling($subId, $creditCardNumber);

        // since we use the authorized variables as tag conditionals in submitted_order_info,
        // we won't throw any errors from here on out
        ee()->form_builder->set_show_errors(false);

        if ($state->isAuthorized()) {
            ee()->form_builder->set_return(ee()->cartthrob->cart->order('authorized_redirect'));
        } else {
            ee()->form_builder
                ->set_return(ee()->cartthrob->cart->order('failed_redirect'))
                ->add_error($state->getMessage());
        }

        ee()->cartthrob->cart->save();

        ee()->form_builder->action_complete();
    }

    public function delete_recurrent_billing_form()
    {
        if (ee()->session->userdata('member_id') == 0) {
            ee()->template_helper->tag_redirect(ee()->TMPL->fetch_param('logged_out_redirect'));
        }

        ee()->load->library('api/api_cartthrob_payment_gateways');

        if (ee()->TMPL->fetch_param('gateway')) {
            ee()->api_cartthrob_payment_gateways->setGateway(ee()->TMPL->fetch_param('gateway'));
        }

        $data = $this->globalVariables(true);

        $data['gateway_fields'] = ee()->api_cartthrob_payment_gateways->gateway_fields(false,
            'recurrent_billing_delete');

        ee()->load->library('form_builder');

        ee()->form_builder->initialize([
            'classname' => 'Cartthrob',
            'method' => 'delete_recurrent_billing_action',
            'params' => ee()->TMPL->tagparams,
            'content' => ee()->template_helper->parse_variables_row($data),
            'form_data' => [
                'action',
                'secure_return',
                'return',
                'language',
            ],
            'encoded_form_data' => [
                'required' => 'REQ',
                'sub_id' => 'SD',
                'gateway' => 'gateway',
            ],
            'encoded_numbers' => [
                'order_id' => 'OI',
            ],
            'encoded_bools' => [
                'allow_user_price' => 'AUP',
                // 'show_errors' => array('ERR', TRUE),
                'json' => 'JSN',
            ],
        ]);

        return ee()->form_builder->form();
    }

    public function delete_recurrent_billing_action()
    {
        if (!ee()->input->get_post('ACT')) {
            return;
        }

        ee()->cartthrob->save_customer_info();

        ee()->load->library('form_validation');
        ee()->load->library('form_builder');

        ee()->form_builder->set_show_errors(true)
            ->set_success_callback([ee()->cartthrob, 'action_complete'])
            ->set_error_callback([ee()->cartthrob, 'action_complete']);

        if (!ee()->cartthrob->store->config('save_orders')) {
            ee()->form_builder->action_complete();
        }

        ee()->load->library('languages');

        ee()->languages->set_language(ee()->input->post('language', true));

        $not_required = [];
        $required = [];

        if (ee()->input->post('REQ')) {
            $required_string = ee('Security/XSS')->clean(ee('Encrypt')->decode(ee()->input->post('REQ')));

            if (preg_match('/^not (.*)/', $required_string, $matches)) {
                $not_required = explode('|', $matches[1]);
                $required_string = '';
            }

            if ($required_string) {
                $required = explode('|', $required_string);
            }

            unset($required_string);
        }

        $gateway = (ee()->input->post('gateway')) ? ee('Security/XSS')->clean(ee('Encrypt')->decode(ee()->input->post('gateway'))) : ee()->cartthrob->store->config('payment_gateway');

        // Load the payment processing plugin that's stored in the extension's settings.
        ee()->load->library('cartthrob_payments');

        if (!ee()->cartthrob_payments->setGateway($gateway)->gateway()) {
            ee()->form_builder
                ->add_error(ee()->lang->line('invalid_payment_gateway'))
                ->action_complete();
        }

        $authorized_redirect = ee()->input->post('authorized_redirect', true);
        $failed_redirect = ee()->input->post('failed_redirect', true);
        $declined_redirect = ee()->input->post('declined_redirect', true);

        if (ee()->input->post('OI')) {
            $data = ee('Security/XSS')->clean(ee('Encrypt')->decode(ee()->input->post('OI')));

            if ($data == abs(Number::sanitize($data))) { // ignore a non-numeric input
                $order_id = $data;
            }
        }

        if (ee()->input->post('SD')) {
            $subId = ee('Security/XSS')->clean(ee('Encrypt')->decode(ee()->input->post('SD')));
        }

        foreach ($not_required as $key) {
            unset($required[array_search($key, $required)]);
        }

        if (!ee()->form_builder->set_required($required)->validate()) {
            ee()->form_builder->action_complete();
        }

        ee()->load->model('order_model');

        $order_data = ee()->order_model->order_data_array();

        ee()->cartthrob->cart->set_order($order_data);

        ee()->cartthrob->cart->save();

        /** @var TransactionState $state */
        $state = ee()->cartthrob_payments->deleteRecurrentBilling($subId);

        ee()->cartthrob->cart->update_order($state->toArray());

        ee()->session->set_flashdata($state->toArray());

        // since we use the authorized variables as tag conditionals in submitted_order_info,
        // we won't throw any errors from here on out
        ee()->form_builder->set_show_errors(false);

        if ($state->isAuthorized()) {
            ee()->form_builder->set_return(ee()->cartthrob->cart->order('authorized_redirect'));
        } else {
            ee()->form_builder
                ->set_return(ee()->cartthrob->cart->order('failed_redirect'))
                ->add_error($state->getMessage());
        }

        ee()->cartthrob->cart->save();

        ee()->form_builder->action_complete();
    }

    public function subscription_select()
    {
        ee()->load->helper('form');
        ee()->load->model('subscription_model');

        $name = (ee()->TMPL->fetch_param('name')) ? ee()->TMPL->fetch_param('name') : 'subscription_interval_units';

        if ($name == 'subscription') {
            $name = 'SUB';
        }
        $selected = (ee()->TMPL->fetch_param('selected')) ? ee()->TMPL->fetch_param('selected') : ee()->TMPL->fetch_param('default');
        $temp_name = str_replace('subscription_', '', $name);

        if (!$selected && $item = ee()->cartthrob->cart->item(ee()->TMPL->fetch_param('row_id'))) {
            ee()->load->helper('array');
            $opt = element($temp_name, $item->meta('subscription_options'));
            if ($item->meta('subscription_options') && $opt !== false) {
                $selected = $opt;
            }
        }

        $options = (ee()->TMPL->fetch_param('options') ? ee()->TMPL->fetch_param('options') : 'days|weeks|months|years');

        // need to get the encoded key SUB
        $keys = ee()->subscription_model->option_keys();
        $encoded_key = array_search($temp_name, $keys);
        if ($encoded_key) {
            $name = $encoded_key;
        }
        $options = explode('|', $options);
        if ($name == 'PI') {
            if (in_array('days', $options)) {
                // either no options were passed in or someone screwed up. Clear the options if it has days in the option array
                $options = null;
            }
            $temp_options = [];
            $sub_params['order_by'][] = 'name';
            $sub_params['sort'][] = 'asc';
            $all_plans = ee()->subscription_model->get_plans($sub_params, 100);

            if (is_array($all_plans) && count($all_plans)) {
                if (!empty($options)) {
                    foreach ($all_plans as $p) {
                        if (in_array($p['id'], $options)) {
                            $temp_options[] = $p['id'] . ':' . $p['name'];
                        }
                    }
                } else {
                    foreach ($all_plans as $p) {
                        $temp_options[] = $p['id'] . ':' . $p['name'];
                    }
                }

                $options = $temp_options;
            }
        }

        $revised_options = [];
        foreach ($options as $option_value => $option_name) {
            // format: options="12:1 year|24:2 years|36:3 years"
            if (strpos($option_name, ':') !== false) {
                list($option_value, $option_name) = explode(':', $option_name);
            } else {
                $option_value = $option_name;
            }

            $encoded_value = ee('Encrypt')->encode(trim($option_value));

            if ($option_value == $selected) { // have to do this because an unencoded value won't = the encoded version of same
                $selected = $encoded_value;
            }
            $revised_options[$encoded_value] = $option_name;
        }
        if (bool_string(ee()->TMPL->fetch_param('add_blank'))) {
            $blank = ['' => '---'];
            $revised_options = array_merge($blank, $revised_options);
        }

        $attrs = [];

        if (ee()->TMPL->fetch_param('id')) {
            $attrs['id'] = ee()->TMPL->fetch_param('id');
        }

        if (ee()->TMPL->fetch_param('class')) {
            $attrs['class'] = ee()->TMPL->fetch_param('class');
        }

        if (ee()->TMPL->fetch_param('onchange')) {
            $attrs['onchange'] = ee()->TMPL->fetch_param('onchange');
        }

        $extra = '';

        if ($attrs) {
            $extra .= _attributes_to_string($attrs);
        }

        if (ee()->TMPL->fetch_param('extra')) {
            if (substr(ee()->TMPL->fetch_param('extra'), 0, 1) != ' ') {
                $extra .= ' ';
            }

            $extra .= ee()->TMPL->fetch_param('extra');
        }

        return form_dropdown(
            $name,
            $revised_options,
            $selected,
            $extra
        );
    }

    public function update_subscription_form()
    {
        ee()->load->library('form_builder');
        $id = ee()->TMPL->fetch_param('sub_id');
        $subs = null;

        if (!$id) {
            ee()->cartthrob->set_error(lang('you_must_supply_a_subscription_id'));
        } else {
            ee()->load->model('subscription_model');

            $subs = ee()->subscription_model->get_subscription($id);
        }

        if (!$subs) {
            ee()->cartthrob->set_error(lang('no_subscription_by_that_id'));
        }

        if (ee()->form_builder->errors()) {
            return ee()->form_builder->action_complete();
        }

        return $this->checkout_form();
    }

    public function update_subscription_details()
    {
        $id = ee()->TMPL->fetch_param('sub_id');

        ee()->load->model('subscription_model');

        // this should NOT be a db search parameter of: sub_id, which is assigned by the payment provider.
        $params = ['id' => $id];

        if (ee()->session->userdata('group_id') != 1) {
            $params['member_id'] = ee()->session->userdata('member_id');
        }

        // @TODO for now only the member can update his own sub
        $subs = ee()->subscription_model->get_subscriptions($params);

        if (!$subs) {
            return ee()->TMPL->no_results();
        }

        $sub = array_shift($subs);

        ee()->load->library('form_builder');

        $data = array_merge(
            $sub,
            $this->globalVariables(true)
        );

        $this->addEncodedOptionVars($data);

        $encoded_form_data = [];
        $form_data = ['sub_id'];

        foreach (ee()->subscription_model->columns as $key => $default) {
            if (in_array($key, ['name', 'description'])) {
                $form_data[] = 'subscription_' . $key;
            } else {
                if (ee()->TMPL->fetch_param('subscription_' . $key)) {
                    $encoded_form_data['subscription_' . $key] = 'subscription_' . $key;
                }
            }
        }

        ee()->form_builder->initialize([
            'form_data' => $form_data,
            'encoded_form_data' => $encoded_form_data,
            'classname' => 'Cartthrob',
            'method' => 'update_subscription_action',
            'params' => ee()->TMPL->tagparams,
            'content' => ee()->template_helper->parse_variables_row($data),
        ]);

        ee()->form_builder->set_hidden('sub_id', ee()->TMPL->fetch_param('sub_id', ee()->TMPL->fetch_param('sub_id')));

        return ee()->form_builder->form();
    }

    public function update_subscription_action()
    {
        ee()->load->library(['form_builder', 'encrypt']);

        ee()->load->model('subscription_model');

        $data = ['id' => ee()->input->post('sub_id')];

        ee()->cartthrob->save_customer_info();

        if (!$data['id']) {
            ee()->form_builder
                ->add_error(lang('no_subscription_id'))
                ->action_complete();
        }

        foreach (ee()->subscription_model->columns as $key => $default) {
            $value = null;

            $encoded_bools = ee()->subscription_model->encoded_bools();
            $encoded_form_data = ee()->subscription_model->encoded_form_data();
            $encoded_numbers = ee()->subscription_model->encoded_numbers();
            if (($value = ee()->input->post('subscription_' . $key)) !== false) {
                $data[$key] = in_array($key, ['name', 'description']) ? $value : ee('Encrypt')->decode($value);
            } elseif (isset($encoded_form_data['subscription_' . $key]) && ($value = ee()->input->post($encoded_form_data['subscription_' . $key])) !== false) {
                $data[$key] = ee('Encrypt')->decode($value);
            } elseif (isset($encoded_bools['subscription_' . $key]) && ($value = ee()->input->post($encoded_bools['subscription_' . $key])) !== false) {
                $data[$key] = ee('Encrypt')->decode($value);
            } elseif (isset($encoded_numbers['subscription_' . $key]) && ($value = ee()->input->post($encoded_numbers['subscription_' . $key])) !== false) {
                $data[$key] = ee('Encrypt')->decode($value);
            }
        }
        if (!ee()->subscription_model->validate($data)) {
            return ee()->form_builder
                ->add_error(ee()->subscription_model->errors)
                ->action_complete();
        }

        // check to see if the plan is changing
        $current_subscription = ee()->subscription_model->get_subscription($data['id']);
        if (isset($data['plan_id']) && ($current_subscription['plan_id'] != $data['plan_id'])) {
            $permissions_id = [];

            // update permissions when a plan changes
            ee()->load->model('permissions_model');
            // get the current permissions for this id
            $current_permissions_data = (array)ee()->permissions_model->get(['sub_id' => $data['id']], null, 0,
                true);
            // get the permissions for the new plan
            $new_plan = ee()->subscription_model->get_plan($data['plan_id']);
            $new_plan_permissions = unserialize(base64_decode($new_plan['permissions']));

            // let's go ahead and delete the permissions that we no longer want
            if (!empty($current_permissions_data)) {
                foreach ($current_permissions_data as $current_perm) {
                    if ($new_plan_permissions) {
                        if (($key = array_search($current_perm['permission'], $new_plan_permissions)) !== false) {
                            // it was in the array, so I'm removing it from the new permissions array
                            // when I'm done deleting unwanted permissions, I'll use what's left in the new permissions data to create new permissions
                            unset($new_plan_permissions[$key]);
                            // push the id to the permissions_id array
                            $permissions_id[] = $current_perm['id'];
                        } else {
                            // we don't want this permission anymore, delete it
                            ee()->permissions_model->delete($current_perm['id']);
                        }
                    } else {
                        // apparently we don't want any permissions anymore, deleting them all
                        ee()->permissions_model->delete($current_perm['id']);
                    }
                }
            }

            // var_dump($current_subscription);
            if (!empty($new_plan_permissions)) {
                foreach ($new_plan_permissions as $perm) {
                    $perm_id = ee()->permissions_model->update([
                        'member_id' => $current_subscription['member_id'],
                        'permission' => $perm,
                        'item_id' => (isset($current_subscription['entry_id'])) ? $current_subscription['entry_id'] : 000,
                        'order_id' => $current_subscription['order_id'],
                        'sub_id' => $data['id'],
                    ]);

                    // the permission ids need to get updated in the subscription table
                    $permissions_id[] = $perm_id;
                }
            }

            // going to add the permission ids into the subscription
            // should have the serialized item from the current subscription, unserialize it, add the permissions_id, then reserialize it
            if (isset($current_subscription['serialized_item'])) {
                $unserialized_item = unserialize(base64_decode($current_subscription['serialized_item']));
                $unserialized_item['permissions_id'] = $permissions_id;
                $data['serialized_item'] = base64_encode(serialize($unserialized_item));
            }
        }

        ee()->subscription_model->update($data);

        // cartthrob_add_to_cart_start hook
        if (ee()->extensions->active_hook('cartthrob_update_subscription_details') === true) {
            // $edata = $EXT->universal_call_extension('cartthrob_update_subscription_details', $data);
            ee()->extensions->call('cartthrob_update_subscription_details', $data);
            if (ee()->extensions->end_script === true) {
                return;
            }
        }

        ee()->form_builder->set_success_callback([ee()->cartthrob->cart, 'save'])
            ->action_complete();
    }

    public function vaults()
    {
        ee()->load->model('vault_model');

        $variables = [];

        $params = [];

        if (ee()->TMPL->fetch_param('id')) {
            $params['id'] = (strstr(ee()->TMPL->fetch_param('id'), '|') !== false) ? explode('|',
                ee()->TMPL->fetch_param('id')) : ee()->TMPL->fetch_param('id');
        }

        if (ee()->TMPL->fetch_param('order_id')) {
            $params['order_id'] = (strstr(ee()->TMPL->fetch_param('order_id'), '|') !== false) ? explode('|',
                ee()->TMPL->fetch_param('order_id')) : ee()->TMPL->fetch_param('order_id');
        }

        if (ee()->TMPL->fetch_param('member_id')) {
            if (in_array(ee()->TMPL->fetch_param('member_id'),
                ['CURRENT_USER', '{member_id}', '{logged_in_member_id}'])) {
                $params['member_id'] = ee()->session->userdata('member_id');
            } else {
                $params['member_id'] = (strstr(ee()->TMPL->fetch_param('member_id'), '|') !== false) ? explode('|',
                    ee()->TMPL->fetch_param('member_id')) : ee()->TMPL->fetch_param('member_id');
            }
        }

        // default to current member's vaults if no other params are specified
        if (!$params) {
            $params = ['member_id' => ee()->session->userdata('member_id')];
        }

        // @TODO add pagination

        $params['limit'] = (ee()->TMPL->fetch_param('limit')) ? ee()->TMPL->fetch_param('limit') : 100;

        $variables = ee()->vault_model->get_vaults($params);

        if (!$variables) {
            return ee()->TMPL->no_results();
        }

        return ee()->template_helper->parse_variables($variables);
    }

    public function subscriptions()
    {
        ee()->load->model('subscription_model');
        ee()->load->library('number');

        $variables = [];

        $params = [];

        if (ee()->TMPL->fetch_param('id')) {
            $params['id'] = (strstr(ee()->TMPL->fetch_param('id'), '|') !== false) ? explode('|',
                ee()->TMPL->fetch_param('id')) : ee()->TMPL->fetch_param('id');
        }

        if (ee()->TMPL->fetch_param('order_id')) {
            $params['order_id'] = (strstr(ee()->TMPL->fetch_param('order_id'), '|') !== false) ? explode('|',
                ee()->TMPL->fetch_param('order_id')) : ee()->TMPL->fetch_param('order_id');
        }

        if (ee()->TMPL->fetch_param('member_id')) {
            if (in_array(ee()->TMPL->fetch_param('member_id'),
                ['CURRENT_USER', '{member_id}', '{logged_in_member_id}'])) {
                $params['member_id'] = ee()->session->userdata('member_id');
            } else {
                $params['member_id'] = (strstr(ee()->TMPL->fetch_param('member_id'), '|') !== false) ? explode('|',
                    ee()->TMPL->fetch_param('member_id')) : ee()->TMPL->fetch_param('member_id');
            }
        }

        // default to current member's vaults if no other params are specified
        if (!$params && ee()->session->userdata('group_id') != 1) {
            $params = ['member_id' => ee()->session->userdata('member_id')];
        }

        // @TODO add pagination

        $params['limit'] = (ee()->TMPL->fetch_param('limit')) ? ee()->TMPL->fetch_param('limit') : 100;

        if (!ee()->TMPL->fetch_param('status')) {
            ee()->db->where('status !=', 'closed');
        } else {
            $params['status'] = ee()->TMPL->fetch_param('status');
        }

        if (is_array(ee()->TMPL->tagparams)) {
            $params = array_merge(ee()->TMPL->tagparams, $params);
        }
        $data = ee()->subscription_model->get_subscriptions($params);

        if (empty($params['member_id']) && ee()->session->userdata('group_id') != 1) {
            return ee()->TMPL->no_results();
        }

        ee()->load->model('order_model');
        foreach ($data as $k => &$row) {
            $item = _unserialize($row['serialized_item'], true);

            if (!empty($row['plan_id'])) {
                $plan = ee()->subscription_model->get_plan($row['plan_id']);
                if (!$plan) {
                    // plan doesn't exist anymore
                    unset($data[$k]);
                    continue;
                } else {
                    if (isset($plan['id'])) {
                        unset($plan['id']);
                    }
                    if (array_key_exists('used_total_occurrences', $plan)) {
                        unset($plan['used_total_occurrences']);
                    }
                    if (array_key_exists('used_trial_occurrences', $plan)) {
                        unset($plan['used_trial_occurrences']);
                    }
                    if (isset($plan['status'])) {
                        unset($plan['status']);
                    }

                    if (empty($row['name'])) {
                        if (!empty($plan['name'])) {
                            $row['name'] = $plan['name'];
                        }
                    }

                    $row = array_merge($row, $plan);
                }
            }
            $row['entry_id'] = isset($item['product_id']) ? $item['product_id'] : '';

            if (isset($row['permissions'])) {
                $perms = @unserialize(base64_decode($row['permissions']));
                if (is_array($perms)) {
                    $row['permissions'] = implode('|', $perms);
                } else {
                    $row['permissions'] = $perms;
                }
            }

            if ($row['start_date'] === '0') {
                $row['start_date'] = null;
            }
            if ($row['end_date'] === '0') {
                $row['end_date'] = null;
            }
            if ($row['last_bill_date'] === '0') {
                $row['last_bill_date'] = null;
            }

            $last_billing = ($row['last_bill_date']) ? $row['last_bill_date'] : $row['start_date'];
            $last_billing = ($last_billing) ? $last_billing : strtotime('now');

            $date_string = @date('Y-m-d',
                    $last_billing) . '+  ' . $row['interval_length'] . '  ' . $row['interval_units'];

            $row['next_billing_date'] = strtotime($date_string);

            if (array_key_exists('price', $row)) {
                $row['price_numeric'] = $row['price'];
                $row['price'] = ee()->number->format($row['price']);
                // $row['last_bill_date'] = NULL;
            }

            unset($row['serialized_item']);
            // @TODO need to delete rows if there's no order to back it up'
        }

        ee()->load->library('data_filter');

        $order_by = (ee()->TMPL->fetch_param('order_by')) ? ee()->TMPL->fetch_param('order_by') : ee()->TMPL->fetch_param('orderby');

        ee()->data_filter->sort($data, $order_by, ee()->TMPL->fetch_param('sort'));
        ee()->data_filter->limit($data, ee()->TMPL->fetch_param('limit'), ee()->TMPL->fetch_param('offset'));

        ee()->template_helper->apply_search_filters($data);

        if (!$data) {
            return ee()->TMPL->no_results();
        }

        return ee()->template_helper->parse_variables($data);
    }

    public function has_subscription_permission()
    {
        if (!ee()->session->userdata('member_id')) {
            return ee()->TMPL->no_results();
        }

        $params = [];

        if (in_array(ee()->TMPL->fetch_param('member_id'),
            ['CURRENT_USER', '{member_id}', '{logged_in_member_id}'])) {
            $params['member_id'] = ee()->session->userdata('member_id');
        } else {
            $params['member_id'] = (strstr(ee()->TMPL->fetch_param('member_id'), '|') !== false) ? explode('|',
                ee()->TMPL->fetch_param('member_id')) : ee()->TMPL->fetch_param('member_id');
        }

        if (empty($params['member_id'])) {
            $params['member_id'] = ee()->session->userdata('member_id');
        }
        ee()->load->model('subscription_model');
        ee()->db->where('status', 'open');
        ee()->db->or_where('end_date >', ee()->localize->now);

        $data = null;

        $data = ee()->subscription_model->get_subscriptions($params);

        if (!$data) {
            return ee()->TMPL->no_results();
        } else {
            foreach ($data as $key => $value) {
                $params['sub_id'][] = $value['id'];
            }

            ee()->load->model('permissions_model');

            if (ee()->TMPL->fetch_param('permissions')) {
                $permissions = explode('|', ee()->TMPL->fetch_param('permissions'));
                $params['permission'] = $permissions;
                $query = ee()->permissions_model->get($params, 1);
            } else {
                $query = ee()->permissions_model->get($params, 1);
            }

            if (!empty($query)) {
                // single tag
                if (!ee()->TMPL->tagdata) {
                    return 1;
                }

                return ee()->TMPL->tagdata;
            } else {
                return ee()->TMPL->no_results();
            }
        }

        return ee()->TMPL->no_results();
    }

    public function update_recurrent_billing_form()
    {
        if (ee()->session->userdata('member_id') == 0) {
            ee()->template_helper->tag_redirect(ee()->TMPL->fetch_param('logged_out_redirect'));
        }

        ee()->load->library('api/api_cartthrob_payment_gateways');

        if (ee()->TMPL->fetch_param('gateway')) {
            ee()->api_cartthrob_payment_gateways->setGateway(ee()->TMPL->fetch_param('gateway'));
        }

        $data = $this->globalVariables(true);

        $data['recurrent_billing_fields'] = ee()->api_cartthrob_payment_gateways->gateway_fields(false, 'recurrent_billing_update');
        $data['gateway_fields'] = ee()->api_cartthrob_payment_gateways->gateway_fields();

        ee()->load->library('form_builder');

        ee()->form_builder->initialize([
            'classname' => 'Cartthrob',
            'method' => 'update_recurrent_billing_action',
            'params' => ee()->TMPL->tagparams,
            'content' => ee()->template_helper->parse_variables_row($data),
            'form_data' => [
                'action',
                'secure_return',
                'return',
                'language',
            ],
            'encoded_form_data' => [
                'required' => 'REQ',
                'gateway' => 'gateway',
                'subscription_name' => 'SUN',
                'subscription_start_date' => 'SSD',
                'subscription_end_date' => 'SED',
                'subscription_interval_units' => 'SIU',
                'sub_id' => 'SD',
                'subscription_type' => 'SUT',
            ],
            'encoded_numbers' => [
                'subscription_total_occurrences' => 'SO',
                'subscription_trial_price' => 'ST',
                'subscription_trial_occurrences' => 'SP',
                'subscription_interval_length' => 'SI',
                'order_id' => 'OI',
            ],
            'encoded_bools' => [
                'allow_user_price' => 'AUP',
                // 'show_errors' => array('ERR', TRUE),
                'json' => 'JSN',
                // 'subscription_allow_modification'		=> 'SM',
            ],
        ]);

        return ee()->form_builder->form();
    }
}
