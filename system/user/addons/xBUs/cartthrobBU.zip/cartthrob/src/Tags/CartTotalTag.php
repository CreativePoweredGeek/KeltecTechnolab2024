<?php

namespace CartThrob\Tags;

class CartTotalTag extends Tag
{
    /**
     * Returns total price of all items in cart
     * The formula is subtotal + tax + shipping - discount
     */
    public function process()
    {
        if (tag_param_equals(2, 'numeric')) {
            return ee()->cartthrob->cart->total();
        }

        return sprintf('%s%s',
            $this->param('prefix', '$'),
            number_format(
                ee()->cartthrob->cart->total(),
                $decimals = (int)$this->param('decimals', 2),
                $decimalPoint = $this->param('dec_point', '.'),
                $thousandSeparator = $this->param('thousands_sep', ',')
            )
        );
    }
}
