<?php

namespace CartThrob\Tags;

class CartSubtotalPlusTaxTag extends Tag
{
    /**
     * Returns subtotal price of all items in cart plus tax
     */
    public function process()
    {
        $value = ee()->cartthrob->cart->subtotal_with_tax();

        if (tag_param_equals(2, 'numeric')) {
            return $value;
        }

        return sprintf('%s%s',
            $this->param('prefix', '$'),
            number_format(
                $value,
                $decimals = (int)$this->param('decimals', 2),
                $decimalPoint = $this->param('dec_point', '.'),
                $thousandSeparator = $this->param('thousands_sep', ',')
            )
        );
    }
}
