<?php

namespace CartThrob\Tags;

class CartTaxTag extends Tag
{
    /**
     * Returns total tax amount for cart
     */
    public function process()
    {
        $value = ee()->cartthrob->cart->tax();

        if (tag_param_equals(2, 'numeric')) {
            return $value;
        }

        return sprintf('%s%s',
            $this->param('prefix', '$'),
            number_format(
                $value,
                $decimals = (int)$this->param('decimals', 2),
                $decimalPoint = $this->param('dec_point', '.'),
                $thousandSeparator = $this->param('thousands_sep', ',')
            )
        );
    }
}
