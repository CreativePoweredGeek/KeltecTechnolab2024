<?php

namespace CartThrob\Tags;

class CartSubtotalTag extends Tag
{
    /**
     * Returns subtotal price of all items in cart
     */
    public function process()
    {
        $value = ee()->cartthrob->cart->subtotal();

        switch (tag_param(2)) {
            case 'numeric':
                return $value;

            case 'plus_tax':
                $value = ee()->cartthrob->cart->subtotal_with_tax();

                if (tag_param_equals(3, 'numeric')) {
                    return $value;
                }
                break;
        }

        return sprintf('%s%s',
            $this->param('prefix', '$'),
            number_format(
                $value,
                $decimals = (int)$this->param('decimals', 2),
                $decimalPoint = $this->param('dec_point', '.'),
                $thousandSeparator = $this->param('thousands_sep', ',')
            )
        );
    }
}
