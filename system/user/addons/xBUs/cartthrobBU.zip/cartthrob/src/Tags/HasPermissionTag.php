<?php

namespace CartThrob\Tags;

use EE_Session;

class HasPermissionTag extends Tag
{
    public function __construct(EE_Session $session)
    {
        parent::__construct($session);

        ee()->load->model(['subscription_model', 'permissions_model']);
    }

    public function process()
    {
        if (!$this->memberLoggedIn()) {
            return $this->template->no_results();
        }

        $params = [];

        if (in_array($this->param('member_id'), ['CURRENT_USER', '{member_id}', '{logged_in_member_id}'])) {
            $params['member_id'] = $this->getMemberId();
        } else {
            $params['member_id'] = $this->explodeParam('member_id');
        }

        if (empty($params['member_id'])) {
            $params['member_id'] = $this->getMemberId();
        }

        // checking to see if there's a sub id. if the sub is inactive, the permission is irrelevant.
        if ($this->hasParam('sub_id')) {
            $params['sub_id'] = $this->explodeParam('sub_id');

            ee()->db->where('status', 'open');

            $data = null;

            if (!is_array($params['sub_id']) && strtolower($params['sub_id']) == 'any') {
                unset($params['sub_id']);
                $data = ee()->subscription_model->get_subscriptions($params);
                unset($params['member_id']);
            } else {
                $data = ee()->subscription_model->get_subscriptions($params);
            }

            if (!$data) {
                return $this->template->no_results();
            } else {
                foreach ($data as $key => $value) {
                    $params['sub_id'][] = $value['id'];
                }

                if ($this->hasParam('permissions')) {
                    $params['permission'] = $this->explodeParam('permissions');
                }

                $query = ee()->permissions_model->get($params, 1);

                if (!empty($query)) {
                    // single tag
                    if (!$this->tagdata()) {
                        return 1;
                    }

                    return $this->tagdata();
                } else {
                    return $this->template->no_results();
                }
            }
        }

        if ($this->hasParam('permissions')) {
            $permissions = $this->explodeParam('permissions');

            foreach ($permissions as $key => $value) {
                $params['permission'] = $value;

                $query = ee()->permissions_model->get($params, 1);

                if (!empty($query)) {
                    // single tag
                    if (!$this->tagdata()) {
                        return 1;
                    }

                    return $this->tagdata();
                }
            }
        }

        return $this->template->no_results();
    }
}
