<?php

namespace CartThrob\Tags;

use EE_Session;

class PermissionsTag extends Tag
{
    public function __construct(EE_Session $session)
    {
        parent::__construct($session);

        ee()->load->model(['permissions_model', 'subscription_model']);
    }

    public function process()
    {
        $variables = [];
        $params = [];

        if ($this->hasParam('id')) {
            $params['id'] = $this->explodeParam('id');
        }

        if ($this->hasParam('item_id')) {
            $params['item_id'] = $this->explodeParam('item_id');
        }

        if ($this->hasParam('order_id')) {
            $params['order_id'] = $this->explodeParam('order_id');
        }

        if ($this->hasParam('member_id')) {
            if (in_array($this->param('member_id'), ['CURRENT_USER', '{member_id}', '{logged_in_member_id}'])) {
                $params['member_id'] = $this->getMemberId();
            } else {
                $params['member_id'] = $this->explodeParam('member_id');
            }
        }

        if ($this->hasParam('sub_id')) {
            $subs = $this->explodeParam('sub_id');

            $use = [];
            // look through the subs model to make sure this subscription is open.
            // if it's not open, then don't return anything

            foreach ($subs as $id) {
                $s = ee()->subscription_model->get_subscription($id);
                if (isset($s['status']) && $s['status'] == 'open') {
                    $use[] = $id;
                }
            }

            if (empty($use)) {
                return $this->template->no_results();
            }

            $params['sub_id'] = $use;
        }

        // default to current member's permissions if no other params are specified
        if (!$params) {
            $params = ['member_id' => $this->getMemberId()];
        }

        $params['limit'] = $this->param('limit', 100);

        $variables = ee()->permissions_model->get($params);

        if (empty($variables)) {
            return $this->template->no_results();
        }

        return $this->parseVariables($variables);
    }
}
