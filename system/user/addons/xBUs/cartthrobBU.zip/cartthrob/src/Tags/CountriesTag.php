<?php

namespace CartThrob\Tags;

use EE_Session;

class CountriesTag extends Tag
{
    public function __construct(EE_Session $session)
    {
        parent::__construct($session);

        ee()->load->library('locales');
    }

    public function process()
    {
        $data = [];

        foreach (ee()->locales->countries($this->param('alpha2')) as $abbrev => $country) {
            $data[] = [
                'country_code' => $abbrev,
                'countries:country_code' => $abbrev,
                'country' => $country,
                'countries:country' => $country,
            ];
        }

        return $this->parseVariables($data);
    }
}
