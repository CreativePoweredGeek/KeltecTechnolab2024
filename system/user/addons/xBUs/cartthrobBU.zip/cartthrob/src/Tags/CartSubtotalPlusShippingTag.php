<?php

namespace CartThrob\Tags;

class CartSubtotalPlusShippingTag extends Tag
{
    /**
     * Returns subtotal price of all items in cart plus shipping
     */
    public function process()
    {
        $value = ee()->cartthrob->cart->subtotal() + ee()->cartthrob->cart->shipping();

        if (tag_param_equals(2, 'numeric')) {
            return $value;
        }

        return sprintf('%s%s',
            $this->param('prefix', '$'),
            number_format(
                $value,
                $decimals = (int)$this->param('decimals', 2),
                $decimalPoint = $this->param('dec_point', '.'),
                $thousandSeparator = $this->param('thousands_sep', ',')
            )
        );
    }
}
