<?php

namespace CartThrob\Services\Exceptions;

use Exception;

class PluginRegistrationException extends Exception
{
}
