<?php

namespace CartThrob\Services;

use CartThrob\Math\Number;

class NumberService
{
    /** @var array */
    private $config;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public function sanitize($value, $decimalPoint = null)
    {
        return Number::sanitize(
            $value,
            $decimalPoint ?? $this->config['number_format_defaults_dec_point']
        );
    }
}
