<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * @var array $taxes
 * @var string $pagination
 * @var string $form_open
 * @var string $add_href
 * @var array $settings
 * @var array $tax_plugins
 */
?>

<?= $form_open; ?>
    <table class="mainTable padTable">
    <thead class="">
        <tr>
            <th colspan="2">
                <strong><?=lang('tax_settings'); ?></strong><br />
                <?=lang('tax_global_options'); ?>
            </th>
        </tr>
    </thead>
    <tbody>
        <tr class="<?=alternator('odd', 'even'); ?>">
            <td>
                <label><?=lang('tax_use_shipping_address'); ?></label>
            </td>
            <td style="width:50%;">
            <div class="setting-field">
                <label class="choice mr<?php if ($settings['tax_use_shipping_address']) : ?> chosen<?php endif; ?>">
                <input class='radio' type='radio' name='tax_use_shipping_address' value='1' <?php if ($settings['tax_use_shipping_address']) : ?>checked='checked'<?php endif; ?> />
                    <?=lang('yes'); ?>
                </label>

                <label class="choice mr<?php if (!$settings['tax_use_shipping_address']) : ?> chosen<?php endif; ?>">
                <input class='radio' type='radio' name='tax_use_shipping_address' value='0' <?php if (!$settings['tax_use_shipping_address']) : ?>checked='checked'<?php endif; ?> />
                    <?=lang('no'); ?>
                </label>
            </div>
            </td>
        </tr>
        <tr  class="<?=alternator('odd', 'even'); ?>">
            <td>
                <label><?=lang('tax_rounding_options'); ?></label>
                <div class="subtext"><?=lang('tax_rounding_options_note'); ?></div>
            </td>
            <td style="width:50%">
            <div class="setting-field">
                <label class="choice mr<?php if ($settings['round_tax_only_on_subtotal']) : ?> chosen<?php endif; ?>">
                    <input class='radio' type='radio' name='round_tax_only_on_subtotal' value='1' <?php if ($settings['round_tax_only_on_subtotal']) : ?>checked='checked'<?php endif; ?> />
                    <?=lang('yes'); ?>
                </label>

                <label class="choice mr<?php if (!$settings['round_tax_only_on_subtotal']) : ?> chosen<?php endif; ?>">
                    <input class='radio' type='radio' name='round_tax_only_on_subtotal' value='0' <?php if (!$settings['round_tax_only_on_subtotal']) : ?>checked='checked'<?php endif; ?> />
                    <?=lang('no'); ?>
                </label>
            </div>
            </td>
        </tr>
        <tr  class="<?=alternator('odd', 'even'); ?>">
            <td>
                <label for="select_tax_plugin"><?=lang('tax_choose_a_plugin'); ?></label>
            </td>
            <td style="width:50%">
                <select name='tax_plugin' class='plugins' id="select_tax_plugin">
                    <?php foreach ($tax_plugins as $plugin) : ?>
                        <option value="<?=$plugin['classname']; ?>" <?php if ($settings['tax_plugin'] == $plugin['classname']) : ?>selected="selected"<?php endif; ?>>
                            <?=lang($plugin['title']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
    </tbody>
    </table>

    <?=ee()->load->view('plugin_settings', ['settings' => $settings, 'plugins' => $tax_plugins, 'plugin_type' => 'tax_plugin']); ?>
    <p><input type="submit" name="submit" value="Submit" class="submit" /></p>
<?=form_close(); ?>
 
<?php foreach ($taxes as $key => $value):
    $count = (!isset($count) ? 1 : ++$count);
    $class = (($count % 2 != 0) ? 'even' : 'odd');
 ?>
    <?php if ($count == 1): ?>
        <table class="mainTable padTable">
            <thead class="">
                <tr>
                    <th>
                        <strong><?=lang('tax_name'); ?></strong>
                    </th>
                    <th>
                        <strong><?=lang('tax_percent'); ?></strong>
                    </th>
                    <th>
                        <strong><?=lang('tax_country'); ?></strong>
                    </th>
                    <th>
                        <strong><?=lang('tax_state'); ?></strong>
                    </th>
                    <th>
                        <strong><?=lang('tax_zip'); ?></strong>
                    </th>
                    <th colspan="2">
                        &nbsp;
                    </th>
                </tr>
            </thead>
            <tbody>
    <?php endif; ?>

                <tr class="<?= $class; ?>">
                    <td>
                        <?= $value['tax_name']; ?>
                    </td>
                    <td>
                        %<?php echo number_format((float)$value['percent'], 2, '.', ''); ?>
                    </td>
                    <td>
                        <?= $value['country']; ?>
                    </td>
                    <td>
                        <?= $value['state']; ?>
                    </td>
                    <td>
                        <?= $value['zip']; ?>
                    </td>
                    <td>
                        <a href="<?php echo ee('CP/URL')->make('addons/settings/cartthrob/edit_tax', ['id' => $value['id']]); ?>">
                        <?=lang('edit'); ?> &raquo;</a>
                    </td>
                    <td>
                         <a href="<?php echo ee('CP/URL')->make('addons/settings/cartthrob/delete_tax', ['id' => $value['id']]); ?>">
                         <?=lang('delete'); ?> &raquo;</a>
                    </td>
                </tr>

    <?php if (count($taxes) == $count):  ?>
            </tbody>
        </table>

        <?= $pagination; ?>
    <?php endif; ?>
<?php endforeach; ?>

<fieldset class="plugin_add_new_setting right">
    <a href="<?=$add_href; ?>" class="ct_add_tax_row btn action"><?=lang('tax_add_another_setting'); ?></a>
</fieldset>
