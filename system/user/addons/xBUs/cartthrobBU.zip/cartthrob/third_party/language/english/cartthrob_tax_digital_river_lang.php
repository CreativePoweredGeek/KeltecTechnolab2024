<?php

$lang = [
    'digital_river_tax' => 'Digital River Taxation',
    'digital_river_tax_note' => 'Taxation returned automatically from Digital River API',
];
