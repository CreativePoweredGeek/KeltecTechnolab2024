<?php

return [
    'discount' => [],

    'payment' => [],

    'price' => [],

    'shipping' => [],

    'tax' => [],
];
