<div id="sm-modal" class="modal-wrap hidden">
	<div class="modal">
		<div class="col-group snap">
			<div class="col w-16 last">
				<a class="m-close-sm-export" href="Javascript:void(0);"></a>
				<div class="box">
					<h1 class="main-title"><?= $title;?></h1>
					<h1 class="download-title hidden"><?= $downloadTitle;?></h1>
					<div class="my-model-wrapper col-group ">
						<div class="col paste-content w-12">
							
						</div>
						<div class="col w-4 move-rigth">
							<a href="Javascript:void(0);" copy-content="" class="copy_clip">Copy to clipboard</a>
						</div>
					</div>
					<!-- <div class="alert inline warn sm-alert1"></div>
					<div class="alert inline warn sm-alert2">
						<p>
							<a href="Javascript:void(0);" copy-content="" class="copy_clip">Copy to clipboard</a>
						</p>
					</div> -->
				</div>
			</div>
		</div>
	</div>
</div>