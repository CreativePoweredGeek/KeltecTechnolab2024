<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<?=$data['settings']?>

    <p>
     <input type="submit" name="submit" value="submit" class="btn submit" />
    </p>

<?= form_close ?>