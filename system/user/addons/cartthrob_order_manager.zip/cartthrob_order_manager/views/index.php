<div class="box add-mrg-bottom">
    <?= ee('CP/Alert')->getAllInlines() ?>
</div>

<div class="box table-list-wrap">
    <?= form_open(ee('CP/URL')->make('addons/settings/cartthrob_order_manager'), 'id="reports_filter"') ?>
        Report <?= form_dropdown('report', $reports, $current_report) ?>
        <?= form_submit('', lang('refresh'), 'class="btn submit"') ?>
    <?= form_close() ?>

    <div>
        <?= form_open(ee('CP/URL')->make('addons/settings/cartthrob_order_manager'), 'id="reports_date"') ?>
        <p>
            <?= lang('ct.om.date_range') ?>
            <?= form_dropdown('date-range-select', $range_options) ?>
            <?= lang('ct.om.date_start') ?>
            <input type="text" value="<?=$entry_start_date ?? '' ?>" class="datepicker" name="date_start" size="30" style="width:100px"/>
            <?= lang('ct.om.date_finish') ?>
            <input type="text" value="<?=$entry_end_date ?? '' ?>" class="datepicker" name="date_finish" size="30" style="width:100px"/>
            <?= form_submit('', lang('ct.om.date_range'), 'class="btn submit"') ?>
        </p>
        <?= form_close() ?>
    </div>

    <?php if ($current_report): ?>
        <div id="reports_view">
            <?= $view ?>
        </div>
    <?php else : ?>
        <?= $view ?>
    <?php endif; ?>

    <?= $todays_orders ?>

    <?= $order_totals?>
</div>