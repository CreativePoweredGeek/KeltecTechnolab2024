<div class="app-notice-wrap">
    <?= ee('CP/Alert')->getAllInlines() ?>
</div>

<?= $this->embed('ee:_shared/form') ?>