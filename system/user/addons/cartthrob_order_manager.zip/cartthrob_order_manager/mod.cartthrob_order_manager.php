<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class_alias('CartThrob\OrderManager\Module', 'Cartthrob_order_manager');
