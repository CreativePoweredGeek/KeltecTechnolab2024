<?php

namespace CartThrob\OrderManager;

class Module
{
}
