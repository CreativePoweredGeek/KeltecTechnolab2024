window.CartthrobTokenizer = {};

(function (tokenizer) {
    var ender = require('ender');  // https://www.npmjs.com/package/ender
    var bean = require('bean');    // https://www.npmjs.com/package/bean
    var bonzo = require('bonzo');  // https://www.npmjs.com/package/bonzo
    var qwery = require('qwery');  // https://www.npmjs.com/package/qwery

    tokenizer.form = null;
    tokenizer.submissionState = false;

    tokenizer._submitCb = null;
    tokenizer._successCb = null;
    tokenizer._errorCb = null;

    // -------------------------------------------------
    // Default Handler Methods
    // -------------------------------------------------

    tokenizer.submit = function () {
        this.form.dispatchEvent(_createEvent('ct.payment-form.submit'));

        if (this._submitCb) {
            this._submitCb();
        } else {
            this.success();
        }
    };

    tokenizer.error = function (msg) {
        this.form.dispatchEvent(_createEvent('ct.payment-form.error'));
        this.submissionState = false;

        if (this._errorCb) {
            this._errorCb();
        } else {
            alert(msg);
        }
    };

    tokenizer.success = function (msg) {
        this.form.dispatchEvent(_createEvent('ct.payment-form.success'));
        this.submissionState = false;

        if (this._successCb) {
            this._successCb(msg);
        } else {
            this.form.submit();
        }
    };

    // -------------------------------------------------
    // Setter Methods
    // -------------------------------------------------

    /**
     * Method to call when the checkout form is submitted
     *
     * @param {function} cb
     * @returns {CartthrobTokenizer}
     */
    tokenizer.onSubmit = function (cb) {
        this._submitCb = cb;
        return this;
    };

    /**
     * Method to call when the checkout errors
     *
     * @param {function} cb
     * @returns {CartthrobTokenizer}
     */
    tokenizer.onError = function (cb) {
        this._errorCb = cb;
        return this;
    };

    /**
     * Method to call when the checkout succeeds
     *
     * @param {function} cb
     * @returns {CartthrobTokenizer}
     */
    tokenizer.onSuccess = function (cb) {
        this._successCb = cb;
        return this;
    }

    // -------------------------------------------------
    // Private Methods
    // -------------------------------------------------

    /**
     * @param name
     * @returns {Event}
     * @private
     */
    function _createEvent(name) {
        var event = document.createEvent('Event');
        event.initEvent(name, true, true);
        return event;
    }

    /**
     * Form submission handler
     *
     * @param e
     * @returns {boolean}
     * @private
     */
    function _submit(e) {
        e.preventDefault();

        if (CartthrobTokenizer.submissionState === true) {
            return false;
        }

        CartthrobTokenizer.submissionState = true;

        if (CartthrobTokenizer.beforeSubmit() !== false) {
            CartthrobTokenizer.bindHandler();
        }

        CartthrobTokenizer.submit();

        return false;
    }

    // -------------------------------------------------
    // Deprecated Methods
    // -------------------------------------------------

    /**
     * @deprecated 6.0.0
     */
    tokenizer.submitHandler = tokenizer.submit;

    /**
     * @deprecated 6.0.0
     */
    tokenizer.errorHandler = tokenizer.error;

    /**
     * @deprecated 6.0.0
     */
    tokenizer.successHandler = tokenizer.success;

    /**
     * @deprecated 6.0.0
     */
    tokenizer.setErrorHandler = tokenizer.onError;

    /**
     * @deprecated 6.0.0
     */
    tokenizer.setSubmitHandler = tokenizer.onSubmit;

    /**
     * @deprecated 6.0.0
     */
    tokenizer.bindHandler = function () {
        return true;
    };

    /**
     * @deprecated 6.0.0
     */
    tokenizer.setBindHandler = function (cb) {
        this.bindHandler = cb;
        return this;
    };

    /**
     * Method to run prior to form submission. Returning false will stop submission.
     *
     * @returns {boolean}
     * @deprecated 6.0.0
     */
    tokenizer.beforeSubmit = function () {
        return true;
    };

    /**
     * @param {function} cb
     * @returns {CartthrobTokenizer}
     * @deprecated 6.0.0
     */
    tokenizer.setBeforeSubmit = function (cb) {
        this.beforeSubmit = cb;
        return this;
    };

    // -------------------------------------------------
    // Utility Methods
    // -------------------------------------------------

    /**
     * Add a hidden value to the form
     *
     * @param name
     * @param value
     * @returns {CartthrobTokenizer}
     */
    tokenizer.addHidden = function (name, value) {
        bonzo(this.form).append("<input type=\"hidden\" name=\"" + name + "\" value=\"" + value + "\">");
        return this;
    };

    /**
     * Get an input value from the form
     *
     * @param selector
     * @returns {*|null}
     */
    tokenizer.val = function (selector) {
        return bonzo(ender(this.form).find(selector)).val();
    };

    /**
     * @deprecated 6.0.0
     */
    tokenizer.bindForm = function () {
        bean.add(this.form, "submit", _submit);
    };

    /**
     * @deprecated 6.0.0
     */
    tokenizer.unbindForm = function () {
        bean.remove(this.form, "submit", _submit);
    };

    /**
     * @param bindHandler
     * @param formSelector
     * @returns {CartthrobTokenizer}
     */
    tokenizer.init = function (bindHandler, formSelector) {
        // This conditional is in place to support the old method of using this library prior to rewrite
        // and should go away in CartThrob 6, leaving the first argument to be the form selector and providing
        // no second argument.
        if (typeof(bindHandler) === 'string') {
            formSelector = bindHandler;
            bindHandler = null;
        }

        formSelector = formSelector || "#checkout_form";

        var form = qwery(formSelector);

        if (form.length <= 0) {
            console.error('There was no form with a selector of "' + formSelector + '" found on this page.');
            return this;
        }

        this.form = form.shift();

        if (bindHandler) {
            this.setBindHandler(bindHandler);
        }

        bean.add(this.form, "submit", _submit);

        return this;
    };

})(CartthrobTokenizer);
